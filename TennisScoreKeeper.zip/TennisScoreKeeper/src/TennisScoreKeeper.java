import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class TennisScoreKeeper extends Application {

    private int hours = 0;
    private int minutes = 0;
    private int seconds = 0;
    private Timeline timeline;

    @Override
    public void start(Stage primaryStage) {

        // SET TITLE
        primaryStage.setTitle("DTS Score Keeper");

        //-------------------------------------------------------------------------------------------------------------
        //=============================================================================================================
        // GUI FOR TIMER AND LOGO    ###########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR TIMER AND LOGO )">
        Label labelTimer = new Label("00:00:00");
        labelTimer.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // Create a timeline to update the timer label every second
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Increment seconds and format the time
                seconds++;
                if (seconds == 60) {
                    seconds = 0;
                    minutes++;
                }
                if (minutes == 60) {
                    minutes = 0;
                    hours++;
                }
                String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                labelTimer.setText(time);
            }
        }));
        timeline.setCycleCount(Animation.INDEFINITE);

        // Start the timeline
        timeline.play();

        // HBOX FOR TIMER
        HBox hBoxLabelTimer = new HBox();
        hBoxLabelTimer.getChildren().addAll(labelTimer);
        hBoxLabelTimer.setPrefSize(150, 25);

        // MATCH TIME LABEL AND BOX
        Label labelMatchTime = new Label("MATCH TIME");

        HBox hBoxLabelMatchTime = new HBox();
        hBoxLabelMatchTime.getChildren().addAll(labelMatchTime);
        hBoxLabelMatchTime.setPrefSize(150, 25);

        // VBox FOR MATCH TIME LABEL AND TIMER
        VBox vBoxTimer = new VBox();
        vBoxTimer.setPrefSize(150, 50);
        vBoxTimer.getChildren().addAll(hBoxLabelMatchTime, hBoxLabelTimer);

        Label labelLogo = new Label("DTS");
        labelLogo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        HBox hBoxLabelLogo = new HBox();
        hBoxLabelLogo.getChildren().addAll(labelLogo);
        hBoxLabelLogo.setPrefSize(150, 50);

        HBox hBoxBlankSpaceOne = new HBox();
        hBoxBlankSpaceOne.setPrefSize(300, 50);

        HBox hBoxBottomRowGUI = new HBox();
        hBoxBottomRowGUI.getChildren().addAll(hBoxLabelLogo, hBoxBlankSpaceOne, vBoxTimer);
        hBoxBottomRowGUI.setPrefSize(600, 50);

        //</editor-fold> END OF GUI FOR TIMER AND LOGO
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name
        Label labelPlayerOneName = new Label("Gariggle");
        labelPlayerOneName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneName = new HBox();
        hBoxPlayerOneName.getChildren().addAll(labelPlayerOneName);
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //Plus point button
        Button buttonPlusPointPlayerOne = new Button("+");
        buttonPlusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        Button buttonMinusPointPlayerOne = new Button("-");
        buttonMinusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerOne = new HBox();
        hBoxPlusMinusPointPlayerOne.getChildren().addAll(buttonPlusPointPlayerOne, buttonMinusPointPlayerOne);
        hBoxPlusMinusPointPlayerOne.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerOneNameAndPointControl = new VBox();
        vBoxPlayerOneNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerOneNameAndPointControl.getChildren().addAll(hBoxPlayerOneName, hBoxPlusMinusPointPlayerOne);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        Label labelPlayerOneCountry = new Label();
        labelPlayerOneCountry.setText("USA"); // Temporary string until controls are set
        labelPlayerOneCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneCountry = new HBox();
        hBoxPlayerOneCountry.getChildren().addAll(labelPlayerOneCountry);
        hBoxPlayerOneCountry.setPrefSize(50, 75);// width, height

        //Label for Players Serve Turn
        Label labelPlayerOneServeIndicator = new Label("Serving"); // Temporary String until logic set
        labelPlayerOneServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerOneServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerOneServeIndicator = new HBox();
        hBoxPlayerOneServeIndicator.getChildren().addAll(labelPlayerOneServeIndicator);
        hBoxPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerOneCountryAndServeIndicator = new VBox();
        vBoxPlayerOneCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerOneCountryAndServeIndicator.getChildren().addAll(hBoxPlayerOneCountry, hBoxPlayerOneServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        Label labelPlayerOneCurrentGameScore = new Label();
        labelPlayerOneCurrentGameScore.setText("30"); // Temporary string until controls are set
        labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerOneCurrentGameScore = new VBox();
        vBoxPlayerOneCurrentGameScore.getChildren().addAll(labelPlayerOneCurrentGameScore);
        vBoxPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneAllVBoxes = new HBox();
        hBoxPlayerOneAllVBoxes.getChildren().addAll(vBoxPlayerOneNameAndPointControl,
                                                    vBoxPlayerOneCountryAndServeIndicator,
                                                    vBoxPlayerOneCurrentGameScore);
        hBoxPlayerOneAllVBoxes.setPrefSize(300, 125);// width, height


        //</editor-fold> END OF GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name
        Label labelPlayerTwoName = new Label("Quell");
        labelPlayerTwoName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerTwoName = new HBox();
        hBoxPlayerTwoName.getChildren().addAll(labelPlayerTwoName);
        hBoxPlayerTwoName.setPrefSize(125, 75); // width, height

        //Plus point button
        Button buttonPlusPointPlayerTwo = new Button("+");
        buttonPlusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        Button buttonMinusPointPlayerTwo = new Button("-");
        buttonMinusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerTwo = new HBox();
        hBoxPlusMinusPointPlayerTwo.getChildren().addAll(buttonPlusPointPlayerTwo, buttonMinusPointPlayerTwo);
        hBoxPlusMinusPointPlayerTwo.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerTwoNameAndPointControl = new VBox();
        vBoxPlayerTwoNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoNameAndPointControl.getChildren().addAll(hBoxPlayerTwoName, hBoxPlusMinusPointPlayerTwo);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        Label labelPlayerTwoCountry = new Label();
        labelPlayerTwoCountry.setText("USA"); // Temporary string until controls are set
        labelPlayerTwoCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Name
        HBox hBoxPlayerTwoCountry = new HBox();
        hBoxPlayerTwoCountry.getChildren().addAll(labelPlayerTwoCountry);
        hBoxPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //Label for Players Serve Turn
        Label labelPlayerTwoServeIndicator = new Label(""); // Temporary String until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerTwoServeIndicator = new HBox();
        hBoxPlayerTwoServeIndicator.getChildren().addAll(labelPlayerTwoServeIndicator);
        hBoxPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerTwoCountryAndServeIndicator = new VBox();
        vBoxPlayerTwoCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoCountryAndServeIndicator.getChildren().addAll(hBoxPlayerTwoCountry, hBoxPlayerTwoServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        Label labelPlayerTwoCurrentGameScore = new Label();
        labelPlayerTwoCurrentGameScore.setText("40"); // Temporary string until controls are set
        labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerTwoCurrentGameScore = new VBox();
        vBoxPlayerTwoCurrentGameScore.getChildren().addAll(labelPlayerTwoCurrentGameScore);
        vBoxPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoAllVBoxes = new HBox();
        hBoxPlayerTwoAllVBoxes.getChildren().addAll(vBoxPlayerTwoNameAndPointControl,
                vBoxPlayerTwoCountryAndServeIndicator,
                vBoxPlayerTwoCurrentGameScore);
        hBoxPlayerTwoAllVBoxes.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE SET SCORES)">

        VBox vBoxPlayerOneSetScoreBlankSpace = new VBox();
        vBoxPlayerOneSetScoreBlankSpace.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        Text labelPlayerOneSetScoreSetOne = new Text();// Temporary String
        labelPlayerOneSetScoreSetOne.setText(" " + "6"); // Temporary String
        labelPlayerOneSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        Text labelPlayerOneSetScoreSetOneTiebreak = new Text();
        labelPlayerOneSetScoreSetOneTiebreak.setText("4"); // Temporary String
        labelPlayerOneSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetOne = new TextFlow(labelPlayerOneSetScoreSetOne, labelPlayerOneSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerOneSetScoreSetOne = new VBox();
        vBoxPlayerOneSetScoreSetOne.getChildren().addAll(textFlowPlayerOneSetScoreSetOne);
        vBoxPlayerOneSetScoreSetOne.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        Text labelPlayerOneSetScoreSetTwo = new Text();
        labelPlayerOneSetScoreSetTwo.setText(" " + "6"); // Temporary String
        labelPlayerOneSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        Text labelPlayerOneSetScoreSetTwoTiebreak = new Text();
        labelPlayerOneSetScoreSetTwoTiebreak.setText("4"); // Temporary String
        labelPlayerOneSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetTwo = new TextFlow(labelPlayerOneSetScoreSetTwo, labelPlayerOneSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerOneSetScoreSetTwo = new VBox();
        vBoxPlayerOneSetScoreSetTwo.getChildren().addAll(textFlowPlayerOneSetScoreSetTwo);
        vBoxPlayerOneSetScoreSetTwo.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        Text labelPlayerOneSetScoreSetThree = new Text();
        labelPlayerOneSetScoreSetThree.setText(" " + "7"); // Temporary String
        labelPlayerOneSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        Text labelPlayerOneSetScoreSetThreeTiebreak = new Text();
        labelPlayerOneSetScoreSetThreeTiebreak.setText("6"); // Temporary String
        labelPlayerOneSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetThree = new TextFlow(labelPlayerOneSetScoreSetThree, labelPlayerOneSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerOneSetScoreSetThree = new VBox();
        vBoxPlayerOneSetScoreSetThree.getChildren().addAll(textFlowPlayerOneSetScoreSetThree);
        vBoxPlayerOneSetScoreSetThree.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        Text labelPlayerOneSetScoreSetFour = new Text();
        labelPlayerOneSetScoreSetFour.setText(" " + "6"); // Temporary String
        labelPlayerOneSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        Text labelPlayerOneSetScoreSetFourTiebreak = new Text();
        labelPlayerOneSetScoreSetFourTiebreak.setText("4"); // Temporary String
        labelPlayerOneSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFour = new TextFlow(labelPlayerOneSetScoreSetFour, labelPlayerOneSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerOneSetScoreSetFour = new VBox();
        vBoxPlayerOneSetScoreSetFour.getChildren().addAll(textFlowPlayerOneSetScoreSetFour);
        vBoxPlayerOneSetScoreSetFour.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        Text labelPlayerOneSetScoreSetFive = new Text();
        labelPlayerOneSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerOneSetScoreSetFive.setText(" " + "7"); // Temporary String

        // Tiebreak Score Number Set Five
        Text labelPlayerOneSetScoreSetFiveTiebreak = new Text();
        labelPlayerOneSetScoreSetFiveTiebreak.setText("4"); // Temporary String
        labelPlayerOneSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFive = new TextFlow(labelPlayerOneSetScoreSetFive, labelPlayerOneSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerOneSetScoreSetFive = new VBox();
        vBoxPlayerOneSetScoreSetFive.getChildren().addAll(textFlowPlayerOneSetScoreSetFive);
        vBoxPlayerOneSetScoreSetFive.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneSetScoresFinalBox = new HBox();
        hBoxPlayerOneSetScoresFinalBox.getChildren().addAll(vBoxPlayerOneSetScoreBlankSpace,
                vBoxPlayerOneSetScoreSetOne, vBoxPlayerOneSetScoreSetTwo, vBoxPlayerOneSetScoreSetThree,
                vBoxPlayerOneSetScoreSetFour, vBoxPlayerOneSetScoreSetFive);
        hBoxPlayerOneSetScoresFinalBox.setPrefSize(300, 100);// width, height

        //</editor-fold> END OF GUI FOR PLAYER ONE SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO SET SCORES)">
        VBox vBoxPlayerTwoSetScoreBlankSpace = new VBox();
        vBoxPlayerTwoSetScoreBlankSpace.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        Text labelPlayerTwoSetScoreSetOne = new Text();// Temporary String
        labelPlayerTwoSetScoreSetOne.setText(" " + "7"); // Temporary String
        labelPlayerTwoSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        Text labelPlayerTwoSetScoreSetOneTiebreak = new Text();
        labelPlayerTwoSetScoreSetOneTiebreak.setText("4"); // Temporary String
        labelPlayerTwoSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetOne = new TextFlow(labelPlayerTwoSetScoreSetOne, labelPlayerTwoSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerTwoSetScoreSetOne = new VBox();
        vBoxPlayerTwoSetScoreSetOne.getChildren().addAll(textFlowPlayerTwoSetScoreSetOne);
        vBoxPlayerTwoSetScoreSetOne.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        Text labelPlayerTwoSetScoreSetTwo = new Text();
        labelPlayerTwoSetScoreSetTwo.setText(" " + "7"); // Temporary String
        labelPlayerTwoSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        Text labelPlayerTwoSetScoreSetTwoTiebreak = new Text();
        labelPlayerTwoSetScoreSetTwoTiebreak.setText("4"); // Temporary String
        labelPlayerTwoSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetTwo = new TextFlow(labelPlayerTwoSetScoreSetTwo, labelPlayerTwoSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerTwoSetScoreSetTwo = new VBox();
        vBoxPlayerTwoSetScoreSetTwo.getChildren().addAll(textFlowPlayerTwoSetScoreSetTwo);
        vBoxPlayerTwoSetScoreSetTwo.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        Text labelPlayerTwoSetScoreSetThree = new Text();
        labelPlayerTwoSetScoreSetThree.setText(" " + "6"); // Temporary String
        labelPlayerTwoSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        Text labelPlayerTwoSetScoreSetThreeTiebreak = new Text();
        labelPlayerTwoSetScoreSetThreeTiebreak.setText("6"); // Temporary String
        labelPlayerTwoSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetThree = new TextFlow(labelPlayerTwoSetScoreSetThree, labelPlayerTwoSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerTwoSetScoreSetThree = new VBox();
        vBoxPlayerTwoSetScoreSetThree.getChildren().addAll(textFlowPlayerTwoSetScoreSetThree);
        vBoxPlayerTwoSetScoreSetThree.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        Text labelPlayerTwoSetScoreSetFour = new Text();
        labelPlayerTwoSetScoreSetFour.setText(" " + "7"); // Temporary String
        labelPlayerTwoSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        Text labelPlayerTwoSetScoreSetFourTiebreak = new Text();
        labelPlayerTwoSetScoreSetFourTiebreak.setText("4"); // Temporary String
        labelPlayerTwoSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFour = new TextFlow(labelPlayerTwoSetScoreSetFour, labelPlayerTwoSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerTwoSetScoreSetFour = new VBox();
        vBoxPlayerTwoSetScoreSetFour.getChildren().addAll(textFlowPlayerTwoSetScoreSetFour);
        vBoxPlayerTwoSetScoreSetFour.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        Text labelPlayerTwoSetScoreSetFive = new Text();
        labelPlayerTwoSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerTwoSetScoreSetFive.setText(" " + "6"); // Temporary String

        // Tiebreak Score Number Set Five
        Text labelPlayerTwoSetScoreSetFiveTiebreak = new Text();
        labelPlayerTwoSetScoreSetFiveTiebreak.setText("4"); // Temporary String
        labelPlayerTwoSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFive = new TextFlow(labelPlayerTwoSetScoreSetFive, labelPlayerTwoSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerTwoSetScoreSetFive = new VBox();
        vBoxPlayerTwoSetScoreSetFive.getChildren().addAll(textFlowPlayerTwoSetScoreSetFive);
        vBoxPlayerTwoSetScoreSetFive.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoSetScoresFinalBox = new HBox();
        hBoxPlayerTwoSetScoresFinalBox.getChildren().addAll(vBoxPlayerTwoSetScoreBlankSpace,
                vBoxPlayerTwoSetScoreSetOne, vBoxPlayerTwoSetScoreSetTwo, vBoxPlayerTwoSetScoreSetThree,
                vBoxPlayerTwoSetScoreSetFour, vBoxPlayerTwoSetScoreSetFive);
        hBoxPlayerTwoSetScoresFinalBox.setPrefSize(300, 100);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR SET SCORES NUMBER INDICATORS   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR SET SCORES NUMBER INDICATORS )">

        Label labelSetsText = new Label();
        labelSetsText.setText("SETS"); // Temporary String
        labelSetsText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        VBox vBoxSetsLabel = new VBox();
        vBoxSetsLabel.setPrefSize(50, 100);// width, height
        vBoxSetsLabel.getChildren().addAll(labelSetsText);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set One Number
        Label labelSetOneNumberText = new Label();// Temporary String
        labelSetOneNumberText.setText("1"); // Temporary String
        labelSetOneNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set One Number
        VBox vBoxSetOneNumberText = new VBox();
        vBoxSetOneNumberText.getChildren().addAll(labelSetOneNumberText);
        vBoxSetOneNumberText.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Two Number
        Label labelSetTwoNumberText = new Label();
        labelSetTwoNumberText.setText("2"); // Temporary String
        labelSetTwoNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Two Number
        VBox vBoxSetTwoNumberText = new VBox();
        vBoxSetTwoNumberText.getChildren().addAll(labelSetTwoNumberText);
        vBoxSetTwoNumberText.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Three Number
        Label labelSetThreeNumberText  = new Label();
        labelSetThreeNumberText.setText("3"); // Temporary String
        labelSetThreeNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Three Number
        VBox vBoxSetThreeNumberText  = new VBox();
        vBoxSetThreeNumberText.getChildren().addAll(labelSetThreeNumberText);
        vBoxSetThreeNumberText.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Four Number
        Label labelSetFourNumberText = new Label();
        labelSetFourNumberText.setText("4"); // Temporary String
        labelSetFourNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Four Number
        VBox vBoxSetFourNumberText = new VBox();
        vBoxSetFourNumberText.getChildren().addAll(labelSetFourNumberText);
        vBoxSetFourNumberText.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Five Number
        Label labelSetFiveNumberText = new Label();
        labelSetFiveNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelSetFiveNumberText.setText("5"); // Temporary String

        // VBox for Set Five Number
        VBox vBoxSetFiveNumberText = new VBox();
        vBoxSetFiveNumberText.getChildren().addAll(labelSetFiveNumberText);
        vBoxSetFiveNumberText.setPrefSize(50, 100);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxSetNumberTextFinalBox = new HBox();
        hBoxSetNumberTextFinalBox.getChildren().addAll(vBoxSetsLabel,
                vBoxSetOneNumberText, vBoxSetTwoNumberText, vBoxSetThreeNumberText,
                vBoxSetFourNumberText, vBoxSetFiveNumberText);
        hBoxSetNumberTextFinalBox.setPrefSize(300, 100);// width, height











        //</editor-fold> END OF GUI FOR SET SCORES NUMBER INDICATORS
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR FINAL SCOREBOARD LAYOUT   ##########################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR FINAL SCOREBOARD LAYOUT)">
        VBox vBoxPlayers = new VBox();
        vBoxPlayers.setPrefSize(300, 250); // width, height
        vBoxPlayers.getChildren().addAll(hBoxPlayerOneAllVBoxes, hBoxPlayerTwoAllVBoxes);

        VBox vBoxScores = new VBox();
        vBoxScores.setPrefSize(300, 250); // width, height
        vBoxScores.getChildren().addAll(hBoxPlayerOneSetScoresFinalBox, hBoxSetNumberTextFinalBox, hBoxPlayerTwoSetScoresFinalBox);

        HBox hBoxTopHalfGUI = new HBox();
        hBoxTopHalfGUI.getChildren().addAll(vBoxPlayers, vBoxScores);

        VBox vBoxFullGUI = new VBox();
        vBoxFullGUI.getChildren().addAll(hBoxTopHalfGUI, hBoxBottomRowGUI);

        StackPane layout = new StackPane();
        layout.getChildren().addAll(vBoxFullGUI);

        Scene scene = new Scene(layout, 600, 300);

        // Load the CSS file
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

        //</editor-fold> END OF GUI FOR FINAL SCOREBOARD LAYOUT
        //-------------------------------------------------------------------------------------------------------------
        // BUTTON HANDLERS   #########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">

        buttonPlusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Plus Point Player One Button Clicked!");
            }
        });

        buttonMinusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Minus Point Player One Button Clicked!");
            }
        });

        buttonPlusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Plus Point Player Two Button Clicked!");
            }
        });

        buttonMinusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Minus Point Player Two Button Clicked!");
            }
        });

        //</editor-fold> END OF BUTTON HANDLERS
    }
    // METHODS  ######################################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">
    @Override
    public void stop() {
        // Stop the timeline when the application is closed
        timeline.stop();
    }

    //</editor-fold> END OF METHODS

    public static void main(String[] args) {
        launch(args);
    }
}
