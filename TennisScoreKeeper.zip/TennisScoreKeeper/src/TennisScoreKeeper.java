import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Circle;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javax.swing.*;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TennisScoreKeeper extends Application {

    private int hours = 0;
    private int minutes = 0;
    private int seconds = 0;
    private Timeline timeline;

    //Player One score variables
    int     playerOneCurrentSetScore, playerOneCurrentGameScoreInt, playerOneSetOneScore = 5, playerOneSetOneTiebreakScore,
            playerOneSetTwoScore, playerOneSetTwoTiebreakScore,
            playerOneSetThreeScore, playerOneSetThreeTiebreakScore, playerOneSetFourScore, playerOneSetFourTiebreakScore,
            playerOneSetFiveScore, playerOneSetFiveTiebreakScore, playerOneSetsWon, bestOf = 0, tiebreakPointNumber,
            playerOneTotalPointsWon, numberOfSetsPlayed;

    //Player Two score variables
    int     playerTwoCurrentSetScore, playerTwoCurrentGameScoreInt, playerTwoSetOneScore = 5, playerTwoSetOneTiebreakScore,
            playerTwoSetTwoScore, playerTwoSetTwoTiebreakScore,
            playerTwoSetThreeScore, playerTwoSetThreeTiebreakScore, playerTwoSetFourScore, playerTwoSetFourTiebreakScore,
            playerTwoSetFiveScore, playerTwoSetFiveTiebreakScore, playerTwoSetsWon, playerTwoTotalPointsWon;

    String playerOneNameString = "Player 1", playerTwoNameString = "Player 2",
            playerOneCountryString = "ESP", playerTwoCountryString = "USA";

    boolean playerOneWins = false, playerTwoWins = false, playerOneIsServing = true, playerTwoIsServing = false,
            tiebreakIsHappening = false, setOneComplete = false, setTwoComplete = false, setThreeComplete = false,
            setFourComplete = false, setFiveComplete = false;

    Label labelTimer, labelMatchTime, labelSetGameType, labelSetTiebreakType, labelPlayerOneName,
            labelPlayerOneCountry, labelPlayerOneServeIndicator, labelPlayerOneCurrentGameScore,
            labelPlayerTwoName, labelPlayerTwoCountry, labelPlayerTwoServeIndicator, labelPlayerTwoCurrentGameScore,
            labelSetsText, labelSetOneNumberText, labelSetTwoNumberText, labelSetThreeNumberText,
            labelSetFourNumberText, labelSetFiveNumberText, labelTimerControlLabel;

    TextField textFieldAddPlayerOneName, textFieldAddPlayerTwoName,
            textFieldPlayerOneSetCountry, textFieldPlayerTwoSetCountry;

    Text labelPlayerOneSetScoreSetOne, labelPlayerOneSetScoreSetOneTiebreak,
            labelPlayerOneSetScoreSetTwo, labelPlayerOneSetScoreSetTwoTiebreak,
            labelPlayerOneSetScoreSetThree, labelPlayerOneSetScoreSetThreeTiebreak,
            labelPlayerOneSetScoreSetFour, labelPlayerOneSetScoreSetFourTiebreak,
            labelPlayerOneSetScoreSetFive, labelPlayerOneSetScoreSetFiveTiebreak,
            labelPlayerTwoSetScoreSetOne, labelPlayerTwoSetScoreSetOneTiebreak,
            labelPlayerTwoSetScoreSetTwo, labelPlayerTwoSetScoreSetTwoTiebreak,
            labelPlayerTwoSetScoreSetThree, labelPlayerTwoSetScoreSetThreeTiebreak,
            labelPlayerTwoSetScoreSetFour, labelPlayerTwoSetScoreSetFourTiebreak,
            labelPlayerTwoSetScoreSetFive, labelPlayerTwoSetScoreSetFiveTiebreak;

    Button buttonChangeServer, buttonStartMatch, buttonStopMatch, buttonResumeMatch,
        buttonPauseMatch, buttonPlusPointPlayerOne, buttonMinusPointPlayerOne,
            buttonPlusPointPlayerTwo, buttonMinusPointPlayerTwo;

    RadioButton radioButtonSetOneSet, radioButtonSetThreeSets, radioButtonSetFiveSets, radioButtonSetPlayTiebreak,
            radioButtonTenPointTiebreak, radioButtonSevenPointTiebreak;

    StackPane ballPane;



    @Override
    public void start(Stage primaryStage) {

        // SET TITLE
        primaryStage.setTitle("Tennis Score Keeper");

        //-------------------------------------------------------------------------------------------------------------
        //=============================================================================================================
        // GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS    ###########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS )">
        labelTimer = new Label("00:00:00");
        labelTimer.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // Create a timeline to update the timer label every second
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Increment seconds and format the time
                seconds++;
                if (seconds == 60) {
                    seconds = 0;
                    minutes++;
                }
                if (minutes == 60) {
                    minutes = 0;
                    hours++;
                }
                String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                labelTimer.setText(time);
            }
        }));
        timeline.setCycleCount(Animation.INDEFINITE);

        // HBOX FOR TIMER
        HBox hBoxLabelTimer = new HBox();
        hBoxLabelTimer.getChildren().addAll(labelTimer);
        hBoxLabelTimer.setPrefSize(50, 25);

        // MATCH TIME LABEL AND BOX
        labelMatchTime = new Label("MATCH TIME");

        HBox hBoxLabelMatchTime = new HBox();
        hBoxLabelMatchTime.getChildren().addAll(labelMatchTime);
        hBoxLabelMatchTime.setPrefSize(50, 25);

        // VBox FOR MATCH TIME LABEL AND TIMER
        VBox vBoxTimer = new VBox();
        vBoxTimer.setPrefSize(100, 50);
        vBoxTimer.getChildren().addAll(hBoxLabelMatchTime, hBoxLabelTimer);

        //---------------------------------------------------------------

        // TextFields for Player Names and Countries
        textFieldAddPlayerOneName = new TextField();
        textFieldAddPlayerOneName.setPromptText("Name Player One");
        textFieldAddPlayerTwoName = new TextField();
        textFieldAddPlayerTwoName.setPromptText("Name Player Two");
        textFieldPlayerOneSetCountry = new TextField();
        textFieldPlayerOneSetCountry.setPromptText("Country");
        textFieldPlayerTwoSetCountry = new TextField();
        textFieldPlayerTwoSetCountry.setPromptText("Country");

        //VBox for Setting Names
        VBox vBoxSetNames = new VBox();
        vBoxSetNames.getChildren().addAll(textFieldAddPlayerOneName, textFieldAddPlayerTwoName);
        vBoxSetNames.setPrefSize(120, 50);

        //VBox for Setting Country
        VBox vBoxSetCountry = new VBox();
        vBoxSetCountry.getChildren().addAll(textFieldPlayerOneSetCountry, textFieldPlayerTwoSetCountry);
        vBoxSetCountry.setPrefSize(70, 50);

        //---------------------------------------------------------------

        //Radio Button Section

        // Game Type Radio Button Selection
        labelSetGameType = new Label("Game Type:");
        radioButtonSetOneSet = new RadioButton("1 Set");
        radioButtonSetThreeSets = new RadioButton("3 Sets");
        radioButtonSetFiveSets = new RadioButton("5 Sets");
        radioButtonSetPlayTiebreak = new RadioButton("Tiebreak");

        // Tiebreak Type Radio Button Selection
        labelSetTiebreakType = new Label("Tiebreak Type:");
        radioButtonTenPointTiebreak = new RadioButton("10-point");
        radioButtonSevenPointTiebreak = new RadioButton("7-point");

        // Game Type ToggleGroup
        ToggleGroup toggleGroupGameType = new ToggleGroup();
        radioButtonSetOneSet.setToggleGroup(toggleGroupGameType);
        radioButtonSetThreeSets.setToggleGroup(toggleGroupGameType);
        radioButtonSetFiveSets.setToggleGroup(toggleGroupGameType);
        radioButtonSetPlayTiebreak.setToggleGroup(toggleGroupGameType);

        // Tiebreak Type ToggleGroup
        ToggleGroup toggleGroupTiebreakType = new ToggleGroup();
        radioButtonTenPointTiebreak.setToggleGroup(toggleGroupTiebreakType);
        radioButtonSevenPointTiebreak.setToggleGroup(toggleGroupTiebreakType);

        // Set default selections
        radioButtonSetOneSet.setSelected(true);
        radioButtonTenPointTiebreak.setSelected(true);

        // VBox for Game Type Radio Buttons and Label
        VBox vBoxGameTypeSelectionBox = new VBox();
        vBoxGameTypeSelectionBox.setPrefSize(70, 50);
        vBoxGameTypeSelectionBox.setStyle("-fx-border-style: hidden;");
        vBoxGameTypeSelectionBox.getChildren().addAll( radioButtonSetOneSet,
                radioButtonSetThreeSets, radioButtonSetFiveSets, radioButtonSetPlayTiebreak);

        // VBox for Tiebreak Type Radio Buttons and Label
        VBox vBoxTiebreakSelectionBox = new VBox();
        vBoxTiebreakSelectionBox.setPrefSize(100, 50);
        vBoxTiebreakSelectionBox.setStyle("-fx-border-style: hidden;");
        vBoxTiebreakSelectionBox.getChildren().addAll(labelSetTiebreakType,
                radioButtonTenPointTiebreak, radioButtonSevenPointTiebreak);

        //---------------------------------------------------------------

        // Buttons
        buttonChangeServer = new Button("Change Server");
        buttonChangeServer.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        buttonStartMatch = new Button("Start Match");
        buttonStartMatch.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        buttonStopMatch = new Button("■");
        buttonStopMatch.setAlignment(Pos.TOP_CENTER);
        buttonStopMatch.setDisable(true);
        buttonStopMatch.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        buttonPauseMatch = new Button("⏸");
        buttonPauseMatch.setAlignment(Pos.TOP_CENTER);
        buttonPauseMatch.setDisable(true);
        buttonPauseMatch.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        buttonResumeMatch = new Button("▶");
        buttonResumeMatch.setAlignment(Pos.TOP_CENTER);
        buttonResumeMatch.setDisable(true);
        buttonResumeMatch.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        labelTimerControlLabel = new Label("End | Pause | Play");
        labelTimerControlLabel.setAlignment(Pos.TOP_CENTER);
        labelTimerControlLabel.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        HBox hBoxTimerControlButtons = new HBox();
        hBoxTimerControlButtons.getChildren().addAll(buttonStopMatch, buttonPauseMatch, buttonResumeMatch);

        // VBox for timer control buttons
        VBox vBoxTimerControl = new VBox();
        vBoxTimerControl.getChildren().addAll(labelTimerControlLabel, hBoxTimerControlButtons);
        vBoxTimerControl.setAlignment(Pos.CENTER);
        vBoxTimerControl.setVisible(false);
        vBoxTimerControl.setPrefSize(5, 5);

        // VBox Button Stacks
        VBox vBoxButtonStackOne = new VBox();
        vBoxButtonStackOne.setStyle("-fx-border-style: hidden;");
        vBoxButtonStackOne.setPrefSize(100, 50);
        vBoxButtonStackOne.getChildren().addAll(buttonChangeServer, buttonStartMatch, vBoxTimerControl);

        //HBox for Control space
        HBox hBoxControlSpaceOne = new HBox(10);
        hBoxControlSpaceOne.getChildren().addAll(vBoxGameTypeSelectionBox, vBoxTiebreakSelectionBox,
                vBoxButtonStackOne);
        hBoxControlSpaceOne.setPrefSize(310, 50);

        //---------------------------------------------------------------

        //HBox for bottom row GUI
        HBox hBoxBottomRowGUI = new HBox();
        hBoxBottomRowGUI.getChildren().addAll(vBoxSetNames, vBoxSetCountry, hBoxControlSpaceOne, vBoxTimer);
        hBoxBottomRowGUI.setPrefSize(600, 50);

        //</editor-fold> END OF GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name    labelSetGameType, labelSetTiebreakType, labelPlayerOneName
        labelPlayerOneName = new Label(playerOneNameString);
        labelPlayerOneName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneName = new HBox();
        hBoxPlayerOneName.getChildren().addAll(labelPlayerOneName);
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //Plus point button
        buttonPlusPointPlayerOne = new Button("+");
        buttonPlusPointPlayerOne.setDisable(true);
        buttonPlusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        buttonMinusPointPlayerOne = new Button("-");
        buttonMinusPointPlayerOne.setDisable(true);
        buttonMinusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerOne = new HBox();
        hBoxPlusMinusPointPlayerOne.getChildren().addAll(buttonPlusPointPlayerOne, buttonMinusPointPlayerOne);
        hBoxPlusMinusPointPlayerOne.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerOneNameAndPointControl = new VBox();
        vBoxPlayerOneNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerOneNameAndPointControl.getChildren().addAll(hBoxPlayerOneName, hBoxPlusMinusPointPlayerOne);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        labelPlayerOneCountry = new Label();
        labelPlayerOneCountry.setText(playerOneCountryString); // Temporary string until controls are set
        labelPlayerOneCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneCountry = new HBox();
        hBoxPlayerOneCountry.getChildren().addAll(labelPlayerOneCountry);
        hBoxPlayerOneCountry.setPrefSize(50, 75);// width, height

        Circle tennisBall = new Circle(15, Color.YELLOW);
        tennisBall.setCenterX(15);
        tennisBall.setCenterY(200); // Initial Y position

        // Apply drop shadow effect to the tennis ball
        DropShadow dropShadow = new DropShadow();
        tennisBall.setEffect(dropShadow);


        // Create a StackPane to hold the tennis ball
        ballPane = new StackPane();
        ballPane.getChildren().addAll(tennisBall);

        // Create a translate transition animation to move the tennis ball vertically
        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(0.5), tennisBall);
        translateTransition.setByY(10); // Move the ball by 300 pixels to the right
        translateTransition.setCycleCount(TranslateTransition.INDEFINITE); // Repeat indefinitely
        translateTransition.setAutoReverse(true); // Move back and forth

        // Start the animation
        translateTransition.play();

        //Label for Players Serve Turn
        labelPlayerOneServeIndicator = new Label(); // Temporary String until logic set
        labelPlayerOneServeIndicator.setGraphic(ballPane);
        labelPlayerOneServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerOneServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerOneServeIndicator = new HBox();
        hBoxPlayerOneServeIndicator.getChildren().addAll(labelPlayerOneServeIndicator);
        hBoxPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerOneCountryAndServeIndicator = new VBox();
        vBoxPlayerOneCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerOneCountryAndServeIndicator.getChildren().addAll(hBoxPlayerOneCountry, hBoxPlayerOneServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        labelPlayerOneCurrentGameScore = new Label();
        labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerOneCurrentGameScore = new VBox();
        vBoxPlayerOneCurrentGameScore.getChildren().addAll(labelPlayerOneCurrentGameScore);
        vBoxPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneAllVBoxes = new HBox();
        hBoxPlayerOneAllVBoxes.getChildren().addAll(vBoxPlayerOneNameAndPointControl,
                                                    vBoxPlayerOneCountryAndServeIndicator,
                                                    vBoxPlayerOneCurrentGameScore);
        hBoxPlayerOneAllVBoxes.setPrefSize(300, 125);// width, height


        //</editor-fold> END OF GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name
        labelPlayerTwoName = new Label(playerTwoNameString);
        labelPlayerTwoName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerTwoName = new HBox();
        hBoxPlayerTwoName.getChildren().addAll(labelPlayerTwoName);
        hBoxPlayerTwoName.setPrefSize(125, 75); // width, height

        //Plus point button
        buttonPlusPointPlayerTwo = new Button("+");
        buttonPlusPointPlayerTwo.setDisable(true);
        buttonPlusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        buttonMinusPointPlayerTwo = new Button("-");
        buttonMinusPointPlayerTwo.setDisable(true);
        buttonMinusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerTwo = new HBox();
        hBoxPlusMinusPointPlayerTwo.getChildren().addAll(buttonPlusPointPlayerTwo, buttonMinusPointPlayerTwo);
        hBoxPlusMinusPointPlayerTwo.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerTwoNameAndPointControl = new VBox();
        vBoxPlayerTwoNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoNameAndPointControl.getChildren().addAll(hBoxPlayerTwoName, hBoxPlusMinusPointPlayerTwo);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        labelPlayerTwoCountry = new Label();
        labelPlayerTwoCountry.setText(playerTwoCountryString); // Temporary string until controls are set
        labelPlayerTwoCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Country of Origin
        HBox hBoxPlayerTwoCountry = new HBox();
        hBoxPlayerTwoCountry.getChildren().addAll(labelPlayerTwoCountry);
        hBoxPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //Label for Players Serve Turn
        labelPlayerTwoServeIndicator = new Label(""); // Temporary String until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerTwoServeIndicator = new HBox();
        hBoxPlayerTwoServeIndicator.getChildren().addAll(labelPlayerTwoServeIndicator);
        hBoxPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerTwoCountryAndServeIndicator = new VBox();
        vBoxPlayerTwoCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoCountryAndServeIndicator.getChildren().addAll(hBoxPlayerTwoCountry, hBoxPlayerTwoServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        labelPlayerTwoCurrentGameScore = new Label();
        labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerTwoCurrentGameScore = new VBox();
        vBoxPlayerTwoCurrentGameScore.getChildren().addAll(labelPlayerTwoCurrentGameScore);
        vBoxPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoAllVBoxes = new HBox();
        hBoxPlayerTwoAllVBoxes.getChildren().addAll(vBoxPlayerTwoNameAndPointControl,
                vBoxPlayerTwoCountryAndServeIndicator,
                vBoxPlayerTwoCurrentGameScore);
        hBoxPlayerTwoAllVBoxes.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE SET SCORES)">

        VBox vBoxPlayerOneSetScoreBlankSpace = new VBox();
        vBoxPlayerOneSetScoreBlankSpace.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        labelPlayerOneSetScoreSetOne = new Text();// Temporary String
        labelPlayerOneSetScoreSetOne.setText(" " + playerOneSetOneScore); // Temporary String
        labelPlayerOneSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        labelPlayerOneSetScoreSetOneTiebreak = new Text();
        labelPlayerOneSetScoreSetOneTiebreak.setText("" + playerOneSetOneTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetOne = new TextFlow(labelPlayerOneSetScoreSetOne, labelPlayerOneSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerOneSetScoreSetOne = new VBox();
        vBoxPlayerOneSetScoreSetOne.getChildren().addAll(textFlowPlayerOneSetScoreSetOne);
        vBoxPlayerOneSetScoreSetOne.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        labelPlayerOneSetScoreSetTwo = new Text();
        labelPlayerOneSetScoreSetTwo.setText(" " + playerOneSetTwoScore); // Temporary String
        labelPlayerOneSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        labelPlayerOneSetScoreSetTwoTiebreak = new Text();
        labelPlayerOneSetScoreSetTwoTiebreak.setText("" + playerOneSetTwoTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetTwo = new TextFlow(labelPlayerOneSetScoreSetTwo, labelPlayerOneSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerOneSetScoreSetTwo = new VBox();
        vBoxPlayerOneSetScoreSetTwo.getChildren().addAll(textFlowPlayerOneSetScoreSetTwo);
        vBoxPlayerOneSetScoreSetTwo.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        labelPlayerOneSetScoreSetThree = new Text();
        labelPlayerOneSetScoreSetThree.setText(" " + playerOneSetThreeScore); // Temporary String
        labelPlayerOneSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        labelPlayerOneSetScoreSetThreeTiebreak = new Text();
        labelPlayerOneSetScoreSetThreeTiebreak.setText("" + playerOneSetThreeTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetThree = new TextFlow(labelPlayerOneSetScoreSetThree, labelPlayerOneSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerOneSetScoreSetThree = new VBox();
        vBoxPlayerOneSetScoreSetThree.getChildren().addAll(textFlowPlayerOneSetScoreSetThree);
        vBoxPlayerOneSetScoreSetThree.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        labelPlayerOneSetScoreSetFour = new Text();
        labelPlayerOneSetScoreSetFour.setText(" " + playerOneSetFourScore); // Temporary String
        labelPlayerOneSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        labelPlayerOneSetScoreSetFourTiebreak = new Text();
        labelPlayerOneSetScoreSetFourTiebreak.setText("" + playerOneSetFourTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFour = new TextFlow(labelPlayerOneSetScoreSetFour, labelPlayerOneSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerOneSetScoreSetFour = new VBox();
        vBoxPlayerOneSetScoreSetFour.getChildren().addAll(textFlowPlayerOneSetScoreSetFour);
        vBoxPlayerOneSetScoreSetFour.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        labelPlayerOneSetScoreSetFive = new Text();
        labelPlayerOneSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerOneSetScoreSetFive.setText(" " + playerOneSetFiveScore); // Temporary String


        // Tiebreak Score Number Set Five
        labelPlayerOneSetScoreSetFiveTiebreak = new Text();
        labelPlayerOneSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFive = new TextFlow(labelPlayerOneSetScoreSetFive, labelPlayerOneSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerOneSetScoreSetFive = new VBox();
        vBoxPlayerOneSetScoreSetFive.getChildren().addAll(textFlowPlayerOneSetScoreSetFive);
        vBoxPlayerOneSetScoreSetFive.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneSetScoresFinalBox = new HBox();
        hBoxPlayerOneSetScoresFinalBox.getChildren().addAll(vBoxPlayerOneSetScoreBlankSpace,
                vBoxPlayerOneSetScoreSetOne, vBoxPlayerOneSetScoreSetTwo, vBoxPlayerOneSetScoreSetThree,
                vBoxPlayerOneSetScoreSetFour, vBoxPlayerOneSetScoreSetFive);
        hBoxPlayerOneSetScoresFinalBox.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER ONE SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO SET SCORES)">
        VBox vBoxPlayerTwoSetScoreBlankSpace = new VBox();
        vBoxPlayerTwoSetScoreBlankSpace.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        labelPlayerTwoSetScoreSetOne = new Text();// Temporary String
        labelPlayerTwoSetScoreSetOne.setText(" " + playerTwoSetOneScore); // Temporary String
        labelPlayerTwoSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        labelPlayerTwoSetScoreSetOneTiebreak = new Text();
        labelPlayerTwoSetScoreSetOneTiebreak.setText("" + playerTwoSetOneTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetOne = new TextFlow(labelPlayerTwoSetScoreSetOne, labelPlayerTwoSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerTwoSetScoreSetOne = new VBox();
        vBoxPlayerTwoSetScoreSetOne.getChildren().addAll(textFlowPlayerTwoSetScoreSetOne);
        vBoxPlayerTwoSetScoreSetOne.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        labelPlayerTwoSetScoreSetTwo = new Text();
        labelPlayerTwoSetScoreSetTwo.setText(" " + playerTwoSetTwoScore); // Temporary String
        labelPlayerTwoSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        labelPlayerTwoSetScoreSetTwoTiebreak = new Text();
        labelPlayerTwoSetScoreSetTwoTiebreak.setText("" + playerTwoSetTwoTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetTwo = new TextFlow(labelPlayerTwoSetScoreSetTwo, labelPlayerTwoSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerTwoSetScoreSetTwo = new VBox();
        vBoxPlayerTwoSetScoreSetTwo.getChildren().addAll(textFlowPlayerTwoSetScoreSetTwo);
        vBoxPlayerTwoSetScoreSetTwo.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        labelPlayerTwoSetScoreSetThree = new Text();
        labelPlayerTwoSetScoreSetThree.setText(" " + playerTwoSetThreeScore); // Temporary String
        labelPlayerTwoSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        labelPlayerTwoSetScoreSetThreeTiebreak = new Text();
        labelPlayerTwoSetScoreSetThreeTiebreak.setText("" + playerTwoSetThreeTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetThree = new TextFlow(labelPlayerTwoSetScoreSetThree, labelPlayerTwoSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerTwoSetScoreSetThree = new VBox();
        vBoxPlayerTwoSetScoreSetThree.getChildren().addAll(textFlowPlayerTwoSetScoreSetThree);
        vBoxPlayerTwoSetScoreSetThree.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        labelPlayerTwoSetScoreSetFour = new Text();
        labelPlayerTwoSetScoreSetFour.setText(" " + playerTwoSetFourScore); // Temporary String
        labelPlayerTwoSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        labelPlayerTwoSetScoreSetFourTiebreak = new Text();
        labelPlayerTwoSetScoreSetFourTiebreak.setText("" + playerTwoSetFourTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFour = new TextFlow(labelPlayerTwoSetScoreSetFour, labelPlayerTwoSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerTwoSetScoreSetFour = new VBox();
        vBoxPlayerTwoSetScoreSetFour.getChildren().addAll(textFlowPlayerTwoSetScoreSetFour);
        vBoxPlayerTwoSetScoreSetFour.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        labelPlayerTwoSetScoreSetFive = new Text();
        labelPlayerTwoSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerTwoSetScoreSetFive.setText(" " + playerTwoSetFiveScore); // Temporary String

        // Tiebreak Score Number Set Five
        labelPlayerTwoSetScoreSetFiveTiebreak = new Text();
        labelPlayerTwoSetScoreSetFiveTiebreak.setText("" + playerTwoSetFiveTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFive = new TextFlow(labelPlayerTwoSetScoreSetFive, labelPlayerTwoSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerTwoSetScoreSetFive = new VBox();
        vBoxPlayerTwoSetScoreSetFive.getChildren().addAll(textFlowPlayerTwoSetScoreSetFive);
        vBoxPlayerTwoSetScoreSetFive.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoSetScoresFinalBox = new HBox();
        hBoxPlayerTwoSetScoresFinalBox.getChildren().addAll(vBoxPlayerTwoSetScoreBlankSpace,
                vBoxPlayerTwoSetScoreSetOne, vBoxPlayerTwoSetScoreSetTwo, vBoxPlayerTwoSetScoreSetThree,
                vBoxPlayerTwoSetScoreSetFour, vBoxPlayerTwoSetScoreSetFive);
        hBoxPlayerTwoSetScoresFinalBox.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR SET SCORES NUMBER INDICATORS   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR SET SCORES NUMBER INDICATORS )">

        labelSetsText = new Label();
        labelSetsText.setText("SETS"); // Temporary String
        labelSetsText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        VBox vBoxSetsLabel = new VBox();
        vBoxSetsLabel.setPrefSize(50, 50);// width, height
        vBoxSetsLabel.getChildren().addAll(labelSetsText);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set One Number
        labelSetOneNumberText = new Label();// Temporary String
        labelSetOneNumberText.setText("1"); // Temporary String
        labelSetOneNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set One Number
        VBox vBoxSetOneNumberText = new VBox();
        vBoxSetOneNumberText.getChildren().addAll(labelSetOneNumberText);
        vBoxSetOneNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Two Number
        labelSetTwoNumberText = new Label();
        labelSetTwoNumberText.setText("2"); // Temporary String
        labelSetTwoNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Two Number
        VBox vBoxSetTwoNumberText = new VBox();
        vBoxSetTwoNumberText.getChildren().addAll(labelSetTwoNumberText);
        vBoxSetTwoNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Three Number
        labelSetThreeNumberText  = new Label();
        labelSetThreeNumberText.setText("3"); // Temporary String
        labelSetThreeNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Three Number
        VBox vBoxSetThreeNumberText  = new VBox();
        vBoxSetThreeNumberText.getChildren().addAll(labelSetThreeNumberText);
        vBoxSetThreeNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Four Number
        labelSetFourNumberText = new Label();
        labelSetFourNumberText.setText("4"); // Temporary String
        labelSetFourNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Four Number
        VBox vBoxSetFourNumberText = new VBox();
        vBoxSetFourNumberText.getChildren().addAll(labelSetFourNumberText);
        vBoxSetFourNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Five Number
        labelSetFiveNumberText = new Label();
        labelSetFiveNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelSetFiveNumberText.setText("5"); // Temporary String

        // VBox for Set Five Number
        VBox vBoxSetFiveNumberText = new VBox();
        vBoxSetFiveNumberText.getChildren().addAll(labelSetFiveNumberText);
        vBoxSetFiveNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxSetNumberTextFinalBox = new HBox();
        hBoxSetNumberTextFinalBox.getChildren().addAll(vBoxSetsLabel,
                vBoxSetOneNumberText, vBoxSetTwoNumberText, vBoxSetThreeNumberText,
                vBoxSetFourNumberText, vBoxSetFiveNumberText);
        hBoxSetNumberTextFinalBox.setPrefSize(300, 50);// width, height










        //</editor-fold> END OF GUI FOR SET SCORES NUMBER INDICATORS

        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR CHARTS   ##########################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR CHARTS)">

        // Create initial pie chart data with custom colors
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data(playerOneNameString, playerOneTotalPointsWon),
                new PieChart.Data(playerTwoNameString, playerTwoTotalPointsWon)
        );

        // Create a Pie Chart
        PieChart pieChart = new PieChart(pieChartData);
        pieChart.setTitle("Total Points Won");

        pieChart.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #cccccc; " +
                "-fx-border-width: 1px;");


        // Create an HBox to hold the Pie Chart
        HBox hBoxForCharts = new HBox();
        hBoxForCharts.setPrefSize(300, 325); // width, height
        hBoxForCharts.getChildren().addAll(pieChart);








        //</editor-fold> END OF GUI FOR CHARTS

        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR FINAL SCOREBOARD LAYOUT   ##########################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR FINAL SCOREBOARD LAYOUT)">
        VBox vBoxPlayers = new VBox();
        vBoxPlayers.setPrefSize(300, 250); // width, height
        vBoxPlayers.getChildren().addAll(hBoxPlayerOneAllVBoxes, hBoxPlayerTwoAllVBoxes);

        VBox vBoxScores = new VBox();
        vBoxScores.setPrefSize(300, 250); // width, height
        vBoxScores.getChildren().addAll(hBoxPlayerOneSetScoresFinalBox, hBoxSetNumberTextFinalBox,
                hBoxPlayerTwoSetScoresFinalBox);

        HBox hBoxTopHalfGUI = new HBox();
        hBoxTopHalfGUI.getChildren().addAll(vBoxPlayers, vBoxScores);

        VBox vBoxFullGUI = new VBox();
        vBoxFullGUI.getChildren().addAll(hBoxTopHalfGUI, hBoxBottomRowGUI);

        HBox hBoxGUIWithCharts = new HBox();
        hBoxGUIWithCharts.getChildren().addAll(vBoxFullGUI, hBoxForCharts);

        StackPane layout = new StackPane();
        layout.getChildren().addAll(hBoxGUIWithCharts);

        Scene scene = new Scene(layout, 900, 425);

        // Load the CSS file
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

        //</editor-fold> END OF GUI FOR FINAL SCOREBOARD LAYOUT
        //-------------------------------------------------------------------------------------------------------------
        // BUTTON HANDLERS   #########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">

    buttonStartMatch.setOnAction(event -> {
        System.out.println("Start Match Settings Button Clicked!");

        // Update Scoreboard with names
        String playerOneNameString = "Gariggs";//textFieldAddPlayerOneName.getText();
        String playerTwoNameString = "Quell";//textFieldAddPlayerTwoName.getText();

        //Update chart names
        pieChartData.get(0).setName(playerOneNameString);
        pieChartData.get(1).setName(playerTwoNameString);

        // Update Scoreboard with countries
        String inputCountryOne = "USA";//textFieldPlayerOneSetCountry.getText();
        String inputCountryTwo = "JAP";//textFieldPlayerTwoSetCountry.getText();

        if (!playerOneNameString.isEmpty() && !playerTwoNameString.isEmpty() &&
                !inputCountryOne.isEmpty() && !inputCountryTwo.isEmpty()) {

        //Enable Point Buttons
        buttonMinusPointPlayerTwo.setDisable(false);
        buttonPlusPointPlayerTwo.setDisable(false);
        buttonMinusPointPlayerOne.setDisable(false);
        buttonPlusPointPlayerOne.setDisable(false);

        // Enable Stop, Pause and Resume Match Buttons
        buttonStopMatch.setDisable(false);
        buttonPauseMatch.setDisable(false);
        buttonResumeMatch.setDisable(false);

        // Swap Start match button for Time Controls
        buttonStartMatch.setVisible(false);
        vBoxTimerControl.setVisible(true);

        // Disable Start Match Button
        buttonStartMatch.setDisable(true);

        // Disable Game Type Radio Buttons
        radioButtonSetThreeSets.setDisable(true);
        radioButtonSetFiveSets.setDisable(true);
        radioButtonSetPlayTiebreak.setDisable(true);

        // Disable Tiebreak Type Radio Buttons
        radioButtonTenPointTiebreak.setDisable(true);
        radioButtonSevenPointTiebreak.setDisable(true);

        // Disable Name TextField
        textFieldAddPlayerOneName.setDisable(true);
        textFieldAddPlayerTwoName.setDisable(true);

        // Disable Country TextField
        textFieldPlayerOneSetCountry.setDisable(true);
        textFieldPlayerTwoSetCountry.setDisable(true);

        // Set Names
        playerOneNameString = textFieldAddPlayerOneName.getText();
        playerTwoNameString = textFieldAddPlayerTwoName.getText();
        labelPlayerOneName.setText(playerOneNameString);
        labelPlayerTwoName.setText(playerTwoNameString);

        // Set Country
        playerOneCountryString = textFieldPlayerOneSetCountry.getText();
        playerTwoCountryString = textFieldPlayerTwoSetCountry.getText();
        labelPlayerOneCountry.setText(playerOneCountryString);
        labelPlayerTwoCountry.setText(playerTwoCountryString);

        // Start the match
        startMatch();

        } else {
            // Show an alert
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Empty Text Field");
            alert.setHeaderText(null);
            alert.setContentText("Make sure Player Name and Country have been entered.");
            alert.showAndWait();
        }


    });

        buttonPauseMatch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Match Paused Button Clicked!");

                pause();

            }
        });

        buttonStopMatch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Match Stopped Button Clicked!");

                stop();

            }
        });

        buttonResumeMatch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Match Resume Button Clicked!");

                resume();

            }
        });


        buttonChangeServer.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.out.println("Change Server Button Clicked!");

            if(playerOneIsServing)
            {playAudio("src/audio/playerTwoToServe.mp3");}
            else if(playerTwoIsServing)
            {playAudio("src/audio/playerOneToServe.mp3");}

            changeServer();

        }
    });

    buttonPlusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.out.println("Plus Point Player One Button Clicked!");

            // Update pie chart data
            playerOneTotalPointsWon++;
            pieChartData.get(0).setPieValue(playerOneTotalPointsWon);
            pieChartData.get(0).setName("P1 - " + playerOneTotalPointsWon);

            // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
            // Else use standard tennis scoring
            if(tiebreakIsHappening)
            {
                playerOneCurrentGameScoreInt++;
                labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));

                if (playerOneCurrentGameScoreInt >= tiebreakPointNumber &&
                        playerOneCurrentGameScoreInt - 2 >= playerTwoCurrentGameScoreInt)
                {
                    System.out.println("Player 1 wins the tiebreak!");

                    if (!setOneComplete)
                    {
                     playerOneSetOneScore++;

                     playerOneSetOneTiebreakScore = playerOneCurrentGameScoreInt;
                     labelPlayerOneSetScoreSetOneTiebreak.setText("" + playerOneSetOneTiebreakScore);
                     labelPlayerOneSetScoreSetOne.setText(" " + playerOneSetOneScore);

                     playerTwoSetOneTiebreakScore = playerTwoCurrentGameScoreInt;
                     labelPlayerTwoSetScoreSetOneTiebreak.setText("" + playerTwoSetOneTiebreakScore);

                    playerOneSetsWon++;
                    numberOfSetsPlayed++;

                    alertPlayerOneSetWin();
                    setOneComplete = true;
                    tiebreakIsHappening = false;
                     }
                    else if (!setTwoComplete)
                    {playerOneSetTwoScore++;

                    playerOneSetTwoTiebreakScore = playerOneCurrentGameScoreInt;
                    labelPlayerOneSetScoreSetTwoTiebreak.setText("" + playerOneSetTwoTiebreakScore);
                    labelPlayerOneSetScoreSetTwo.setText(" " + playerOneSetTwoScore);

                    playerTwoSetTwoTiebreakScore = playerTwoCurrentGameScoreInt;
                    labelPlayerTwoSetScoreSetTwoTiebreak.setText("" + playerTwoSetTwoTiebreakScore);

                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                    setTwoComplete = true;
                    tiebreakIsHappening = false;
                    }
                    else if (!setThreeComplete)
                    {playerOneSetThreeScore++;

                    playerOneSetThreeTiebreakScore = playerOneCurrentGameScoreInt;
                    labelPlayerOneSetScoreSetThreeTiebreak.setText("" + playerOneSetThreeTiebreakScore);
                    labelPlayerOneSetScoreSetThree.setText(" " + playerOneSetThreeScore);

                    playerTwoSetThreeTiebreakScore = playerTwoCurrentGameScoreInt;
                    labelPlayerTwoSetScoreSetThreeTiebreak.setText("" + playerTwoSetThreeTiebreakScore);

                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                    setThreeComplete = true;
                    tiebreakIsHappening = false;
                    }
                    else if (!setFourComplete)
                    {playerOneSetFourScore++;

                    playerOneSetFourTiebreakScore = playerOneCurrentGameScoreInt;
                    labelPlayerOneSetScoreSetFourTiebreak.setText("" + playerOneSetFourTiebreakScore);
                    labelPlayerOneSetScoreSetFour.setText(" " + playerOneSetFourScore);

                    playerTwoSetFourTiebreakScore = playerTwoCurrentGameScoreInt;
                    labelPlayerTwoSetScoreSetFourTiebreak.setText("" + playerTwoSetFourTiebreakScore);

                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                    setFourComplete = true;
                    tiebreakIsHappening = false;
                    }
                    else if (!setFiveComplete)
                    {playerOneSetFiveScore++;

                    playerOneSetFiveTiebreakScore = playerOneCurrentGameScoreInt;
                    labelPlayerOneSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore);
                    labelPlayerOneSetScoreSetFive.setText(" " + playerOneSetFiveScore);

                    playerTwoSetFiveTiebreakScore = playerTwoCurrentGameScoreInt;
                    labelPlayerTwoSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore);

                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                    setFiveComplete = true;
                    tiebreakIsHappening = false;
                    }

                }


            }

            // Increment Player Score
            playerOneCurrentGameScoreInt++;

            setCurrentScorePlayerOne();
        }
    });

    buttonMinusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.out.println("Minus Point Player One Button Clicked!");

            // Decrement Player Score
            playerOneCurrentGameScoreInt--;

            // Update pie chart data
            playerOneTotalPointsWon--;
            pieChartData.get(0).setPieValue(playerOneTotalPointsWon);
            pieChartData.get(0).setName("P1 - " + playerOneTotalPointsWon);

            // Make sure Players score is never less than 0
            if(playerOneCurrentGameScoreInt < 0)
            {playerOneCurrentGameScoreInt = 0;}

            // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
            // Else use standard tennis scoring
            if(tiebreakIsHappening)
            {
                labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));
            }else {
                setCurrentScorePlayerOne();
            }
        }
    });

    buttonPlusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.out.println("Plus Point Player Two Button Clicked!");

            // Increment Player Score
            playerTwoCurrentGameScoreInt++;

            // Update pie chart data
            playerTwoTotalPointsWon++;
            pieChartData.get(1).setPieValue(playerTwoTotalPointsWon);
            pieChartData.get(1).setName("P2 - " + playerTwoTotalPointsWon);

            // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
            // Else use standard tennis scoring
            if(tiebreakIsHappening)
            {
                labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));

                if (playerTwoCurrentGameScoreInt >= tiebreakPointNumber &&
                        playerTwoCurrentGameScoreInt - 2 >= playerOneCurrentGameScoreInt)
                {
                    System.out.println("Player 2 wins the tiebreak!");

                    if (!setOneComplete)
                    {playerOneSetOneTiebreakScore = playerOneCurrentGameScoreInt;
                        labelPlayerOneSetScoreSetOneTiebreak.setText("" + playerOneSetOneTiebreakScore);

                        playerTwoSetOneTiebreakScore = playerTwoCurrentGameScoreInt;
                        labelPlayerTwoSetScoreSetOneTiebreak.setText("" + playerTwoSetOneTiebreakScore);

                        setOneComplete = true;}
                    else if (!setTwoComplete)
                    {playerOneSetTwoTiebreakScore = playerOneCurrentGameScoreInt;
                        labelPlayerOneSetScoreSetTwoTiebreak.setText("" + playerOneSetTwoTiebreakScore);

                        playerTwoSetTwoTiebreakScore = playerTwoCurrentGameScoreInt;
                        labelPlayerTwoSetScoreSetTwoTiebreak.setText("" + playerTwoSetTwoTiebreakScore);

                        setTwoComplete = true;}
                    else if (!setThreeComplete)
                    {playerOneSetThreeTiebreakScore = playerOneCurrentGameScoreInt;
                        labelPlayerOneSetScoreSetThreeTiebreak.setText("" + playerOneSetThreeTiebreakScore);

                        playerTwoSetThreeTiebreakScore = playerTwoCurrentGameScoreInt;
                        labelPlayerTwoSetScoreSetThreeTiebreak.setText("" + playerTwoSetThreeTiebreakScore);

                        setThreeComplete = true;}
                    else if (!setFourComplete)
                    {playerOneSetFourTiebreakScore = playerOneCurrentGameScoreInt;
                        labelPlayerOneSetScoreSetFourTiebreak.setText("" + playerOneSetFourTiebreakScore);

                        playerTwoSetFourTiebreakScore = playerTwoCurrentGameScoreInt;
                        labelPlayerTwoSetScoreSetFourTiebreak.setText("" + playerTwoSetFourTiebreakScore);

                        setFourComplete = true;}
                    else if (!setFiveComplete)
                    {playerOneSetFiveTiebreakScore = playerOneCurrentGameScoreInt;
                        labelPlayerOneSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore);

                        playerTwoSetFiveTiebreakScore = playerTwoCurrentGameScoreInt;
                        labelPlayerTwoSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore);

                        setFiveComplete = true;}

                }


            }else {
                setCurrentScorePlayerTwo();
            }
        }
    });

    buttonMinusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.out.println("Minus Point Player Two Button Clicked!");

            // Decrement Player Score
            playerTwoCurrentGameScoreInt--;

            // Update pie chart data
            playerTwoTotalPointsWon--;
            pieChartData.get(1).setPieValue(playerTwoTotalPointsWon);
            pieChartData.get(1).setName("P2 - " + playerTwoTotalPointsWon);

            // Make sure Players score is never less than 0
            if(playerTwoCurrentGameScoreInt < 0)
            {playerTwoCurrentGameScoreInt = 0;}

            // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
            // Else use standard tennis scoring
            if(tiebreakIsHappening)
            {
                labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));
            }else {
                setCurrentScorePlayerTwo();
            }
        }
    });

        //</editor-fold> END OF BUTTON HANDLERS
    }
    // METHODS  ######################################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">

    public void startMatch(){

    // Set both scores to Love
    setCurrentScorePlayerOne();

    //Play play audio
    playAudio("src/audio/play.mp3");

    // Start the timer
    timeline.play();


    // Set Tiebreak and Set Number preferences, transition into tiebreak if that's the game type selected
    if (radioButtonTenPointTiebreak.isSelected())
    {tiebreakPointNumber = 10;}
    else
    {tiebreakPointNumber = 7;}

    if (radioButtonSetOneSet.isSelected())
    {bestOf = 1;}
    else if (radioButtonSetThreeSets.isSelected())
    {bestOf = 3;}
    else if (radioButtonSetFiveSets.isSelected())
    {bestOf = 5;}
    else {
        // Starts a tiebreak
        tiebreakIsHappening = true;
        tiebreak();
    }

    //---------------------------------------------------------------------------------------------------
    // Start Best of 1, 3 or 5 match
    // If best of 3 match, hide sets 4 and 5 labels
    if(bestOf == 1)
    {hideSetsTwoThroughFive();}

    // If best of 3 match, hide sets 4 and 5 labels
    if(bestOf == 3)
    {hideSetsFourAndFive();}


        /*

        AND CHANGING ENDS OF THE COURT
        AND WATER BREAKS ON THOSE CHANGEOVERS


        THEN DO SET WINNING LOGIC BUILT IN WITH TIEBREAKS
        THEN FINISH TIEBREAK LOGIC FOR 10 AND 7 POINTS
        */



    }

    public void tiebreak(){

        /*
        //This needs to go in each players controls
        playerOneSetOneTiebreakScore
        playerOneSetTwoTiebreakScore
        playerOneSetThreeTiebreakScore
        playerOneSetFourTiebreakScore
        playerOneSetFiveTiebreakScore

        playerOneCurrentSetScore

        playerTwoSetOneTiebreakScore
        playerTwoSetTwoTiebreakScore
        playerTwoSetThreeTiebreakScore
        playerTwoSetFourTiebreakScore
        playerTwoSetFiveTiebreakScore

        playerTwoCurrentSetScore

        */


        playAudio("src/audio/tiebreak.mp3");

        //Start of Tiebreak
        playerOneCurrentGameScoreInt = 0;
        playerTwoCurrentGameScoreInt = 0;



        //tiebreakPointNumber


        //playerOneCurrentGameScoreInt++;
        //playerOneTotalPointsWon++;//Update For charts

        //playerTwoCurrentGameScoreInt++;
        //playerTwoTotalPointsWon++;//Update For charts


        //tiebreakPointNumber



        labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));
        labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));

    }





    public void setCurrentScorePlayerOne()
    {
        String outStringOne;
        if(playerOneCurrentGameScoreInt == 0)
        {
            outStringOne = "\uD83D\uDDA4";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 1)
        {
            outStringOne = "15";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 2)
        {
            outStringOne = "30";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 3)
        {
            outStringOne = "40";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        }

        //Set basic scores for Player Two
        String outStringTwo;
        if(playerTwoCurrentGameScoreInt == 0)
        {
            outStringTwo = "\uD83D\uDDA4";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 1)
        {
            outStringTwo = "15";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 2)
        {
            outStringTwo = "30";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 3)
        {
            outStringTwo = "40";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        }

        //Logic for winning a game with no game tiebreak  required
        if(playerOneCurrentGameScoreInt > 3 && playerTwoCurrentGameScoreInt < 3)
        {
            // Increase winners score past 100 to trigger a win
            playerOneCurrentGameScoreInt += 100;
        }

        //Logic for AD scoring
        if(playerOneCurrentGameScoreInt >= 3 && playerOneCurrentGameScoreInt == playerTwoCurrentGameScoreInt)
        {
            outStringOne = "40";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
            labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;");
            playAudio("src/audio/fortyAll.mp3");

            outStringTwo = "40";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
            labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;");
        }
        else if(playerOneCurrentGameScoreInt == playerTwoCurrentGameScoreInt + 1 && playerTwoCurrentGameScoreInt >= 3)
        {
            outStringOne = "A";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
            labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;");
            playAudio("src/audio/advantagePlayerOne.mp3");

            outStringTwo = "";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
            labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;");
        }



        if(playerOneCurrentGameScoreInt == 0)
        {
            if(playerOneCurrentGameScoreInt == 0 && playerTwoCurrentGameScoreInt == 0)
            {playAudio("src/audio/loveAll.mp3");}
            else if(playerOneCurrentGameScoreInt == 0 && playerTwoCurrentGameScoreInt == 1)
            {playAudio("src/audio/loveFifteen.mp3");}
            else if(playerOneCurrentGameScoreInt == 0 && playerTwoCurrentGameScoreInt == 2)
            {playAudio("src/audio/loveThirty.mp3");}
            else if(playerOneCurrentGameScoreInt == 0 && playerTwoCurrentGameScoreInt == 3)
            {playAudio("src/audio/loveForty.mp3");}
        }
        else if(playerOneCurrentGameScoreInt == 1)
        {
            if(playerOneCurrentGameScoreInt == 1 && playerTwoCurrentGameScoreInt == 1)
            {playAudio("src/audio/fifteenAll.mp3");}
            else if(playerOneCurrentGameScoreInt == 1 && playerTwoCurrentGameScoreInt == 0)
                {if(playerTwoIsServing)
                {playAudio("src/audio/loveFifteen.mp3");}
                else{playAudio("src/audio/fifteenLove.mp3");}}
            else if(playerOneCurrentGameScoreInt == 1 && playerTwoCurrentGameScoreInt == 2)
                {if(playerTwoIsServing)
                {playAudio("src/audio/thirtyFifteen.mp3");}
                else{playAudio("src/audio/fifteenThirty.mp3");}}
            else if(playerOneCurrentGameScoreInt == 1 && playerTwoCurrentGameScoreInt == 3)
                {if(playerTwoIsServing)
                {playAudio("src/audio/fortyFifteen.mp3");}
                else{playAudio("src/audio/fifteenForty.mp3");}}
        }
        else if(playerOneCurrentGameScoreInt == 2)
        {
            if(playerOneCurrentGameScoreInt == 2 && playerTwoCurrentGameScoreInt == 2)
            {playAudio("src/audio/thirtyAll.mp3");}
            else if(playerOneCurrentGameScoreInt == 2 && playerTwoCurrentGameScoreInt == 0)
                {if(playerTwoIsServing)
                {playAudio("src/audio/loveThirty.mp3");}
                else{playAudio("src/audio/thirtyLove.mp3");}}
            else if(playerOneCurrentGameScoreInt == 2 && playerTwoCurrentGameScoreInt == 1)
                {if(playerTwoIsServing)
                {playAudio("src/audio/fifteenThirty.mp3");}
                else{playAudio("src/audio/thirtyFifteen.mp3");}}
            else if(playerOneCurrentGameScoreInt == 2 && playerTwoCurrentGameScoreInt == 3)
                {if(playerTwoIsServing)
                {playAudio("src/audio/fortyThirty.mp3");}
                else{playAudio("src/audio/thirtyForty.mp3");}}
        }
        else if(playerOneCurrentGameScoreInt == 3)
        {
            if(playerOneCurrentGameScoreInt == 3 && playerTwoCurrentGameScoreInt == 3)
            {playAudio("src/audio/fortyAll.mp3");}
            else if(playerOneCurrentGameScoreInt == 3 && playerTwoCurrentGameScoreInt == 0)
                {if(playerTwoIsServing)
                {playAudio("src/audio/loveForty.mp3");}
                else{playAudio("src/audio/fortyLove.mp3");}}
            else if(playerOneCurrentGameScoreInt == 3 && playerTwoCurrentGameScoreInt == 1)
                {if(playerTwoIsServing)
                {playAudio("src/audio/fifteenForty.mp3");}
                else{playAudio("src/audio/fortyFifteen.mp3");}}
            else if(playerOneCurrentGameScoreInt == 3 && playerTwoCurrentGameScoreInt == 2)
                {if(playerTwoIsServing)
                {playAudio("src/audio/thirtyForty.mp3");}
                else{playAudio("src/audio/fortyThirty.mp3");}}
        }


        //Logic for winning game tiebreak
        if(playerOneCurrentGameScoreInt > 3 && playerTwoCurrentGameScoreInt >= 3 &&
                playerOneCurrentGameScoreInt > playerTwoCurrentGameScoreInt + 1)
        {
            playerOneCurrentGameScoreInt += 100;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }

        // If player has been given a 100 point boost from the setCurrentScore() method they win the game
        if( playerOneCurrentGameScoreInt > 100)
        {
                alertPlayerOneGameWin();


            changeServer();

            if (!setOneComplete) {
                playerOneSetOneScore++;
                labelPlayerOneSetScoreSetOne.setText(" " + playerOneSetOneScore);


                if((playerOneSetOneScore >= 6 && playerTwoSetOneScore <= 4) ||
                        ((playerOneSetOneScore >= 5 && playerTwoSetOneScore >= 5) &&
                        (playerOneSetOneScore > playerTwoSetOneScore + 1)))
                    {setOneComplete = true;
                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();

                if (playerOneSetOneScore == 6 && playerTwoSetOneScore == 6)
                {tiebreakIsHappening = true;
                    tiebreak();}
                }

            } else if (!setTwoComplete) {
                playerOneSetTwoScore++;

                if (playerOneSetTwoScore == 6 && playerOneSetTwoScore == playerTwoSetTwoScore)
                {tiebreakIsHappening = true;
                    tiebreak();}

                labelPlayerOneSetScoreSetTwo.setText(" " + playerOneSetTwoScore);

                if((playerOneSetTwoScore >= 6 && playerTwoSetTwoScore <= 4) ||
                        ((playerOneSetTwoScore >= 5 && playerTwoSetTwoScore >= 5) &&
                                (playerOneSetTwoScore > playerTwoSetTwoScore + 1)))
                    {setTwoComplete = true;
                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                }
            }else if (!setThreeComplete) {
                playerOneSetThreeScore++;

                if (playerOneSetThreeScore == 6 && playerOneSetThreeScore == playerTwoSetThreeScore)
                {tiebreakIsHappening = true;
                    tiebreak();}

                labelPlayerOneSetScoreSetThree.setText(" " + playerOneSetThreeScore);

                if((playerOneSetThreeScore >= 6 && playerTwoSetThreeScore <= 4) ||
                        ((playerOneSetThreeScore >= 5 && playerTwoSetThreeScore >= 5) &&
                                (playerOneSetThreeScore > playerTwoSetThreeScore + 1)))
                    {setThreeComplete = true;
                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();
                }

            }else if (!setFourComplete) {
                playerOneSetFourScore++;

                if (playerOneSetFourScore == 6 && playerOneSetFourScore == playerTwoSetFourScore)
                {tiebreakIsHappening = true;
                    tiebreak();}

                labelPlayerOneSetScoreSetFour.setText(" " + playerOneSetFourScore);

                if((playerOneSetFourScore >= 6 && playerTwoSetFourScore <= 4) ||
                        ((playerOneSetFourScore >= 5 && playerTwoSetFourScore >= 5) &&
                                (playerOneSetFourScore > playerTwoSetFourScore + 1)))
                    {setFourComplete = true;
                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();

                }

            }else if (!setFiveComplete) {
                playerOneSetFiveScore++;

                if (playerOneSetFiveScore == 6 && playerOneSetFiveScore == playerTwoSetFiveScore)
                {tiebreakIsHappening = true;
                    tiebreak();}

                labelPlayerOneSetScoreSetFive.setText(" " + playerOneSetFiveScore);

                if((playerOneSetFiveScore >= 6 && playerTwoSetFiveScore <= 4) ||
                        ((playerOneSetFiveScore >= 5 && playerTwoSetFiveScore >= 5) &&
                                (playerOneSetFiveScore > playerTwoSetFiveScore + 1)))
                    {setFiveComplete = true;
                    playerOneSetsWon++;
                    numberOfSetsPlayed++;
                    playerOneWins = true;
                    alertPlayerOneSetWin();

                }
            }



        }

    }

    public void setCurrentScorePlayerTwo()
    {

        //Set basic scores for Player One
        String outStringOne;
        if(playerOneCurrentGameScoreInt == 0)
        {
            outStringOne = "\uD83D\uDDA4";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 1)
        {
            outStringOne = "15";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 2)
        {
            outStringOne = "30";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        } else if(playerOneCurrentGameScoreInt == 3)
        {
            outStringOne = "40";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
        }

        //Set basic scores for Player Two
        String outStringTwo;
        if(playerTwoCurrentGameScoreInt == 0)
        {
            outStringTwo = "\uD83D\uDDA4";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 1)
        {
            outStringTwo = "15";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 2)
        {
            outStringTwo = "30";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        } else if(playerTwoCurrentGameScoreInt == 3)
        {
            outStringTwo = "40";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
        }

        //Logic for winning a game with no game tiebreak  required
        if(playerTwoCurrentGameScoreInt > 3 && playerOneCurrentGameScoreInt < 3)
        {
            // Increase winners score past 100 to trigger a win
            playerTwoCurrentGameScoreInt += 100;
        }

        //Logic for AD scoring
        if(playerTwoCurrentGameScoreInt >= 3 && playerTwoCurrentGameScoreInt == playerOneCurrentGameScoreInt)
        {
            outStringOne = "40";
            labelPlayerOneCurrentGameScore.setText(outStringOne);
            labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;");
            playAudio("src/audio/fortyAll.mp3");

            outStringTwo = "40";
            labelPlayerTwoCurrentGameScore.setText(outStringTwo);
            labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;");
        }
        if(playerTwoCurrentGameScoreInt == playerOneCurrentGameScoreInt + 1 && playerOneCurrentGameScoreInt >= 3)
        {
            outStringOne = "A";
            labelPlayerTwoCurrentGameScore.setText(outStringOne);
            labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;");
            playAudio("src/audio/advantagePlayerTwo.mp3");

            outStringTwo = "";
            labelPlayerOneCurrentGameScore.setText(outStringTwo);
            labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;");
        }


        if(playerTwoCurrentGameScoreInt == 0)
        {
            if(playerTwoCurrentGameScoreInt == 0 && playerOneCurrentGameScoreInt == 0)
            {playAudio("src/audio/loveAll.mp3");}
            else if(playerTwoCurrentGameScoreInt == 0 && playerOneCurrentGameScoreInt == 1)
            {playAudio("src/audio/loveFifteen.mp3");}
            else if(playerTwoCurrentGameScoreInt == 0 && playerOneCurrentGameScoreInt == 2)
            {playAudio("src/audio/loveThirty.mp3");}
            else if(playerTwoCurrentGameScoreInt == 0 && playerOneCurrentGameScoreInt == 3)
            {playAudio("src/audio/loveForty.mp3");}

        }
        else if(playerTwoCurrentGameScoreInt == 1)
        {
            if(playerTwoCurrentGameScoreInt == 1 && playerOneCurrentGameScoreInt == 1)
            {playAudio("src/audio/fifteenAll.mp3");}
            else if(playerTwoCurrentGameScoreInt == 1 && playerOneCurrentGameScoreInt == 0)
                {if(playerOneIsServing)
                {playAudio("src/audio/loveFifteen.mp3");}
                else{playAudio("src/audio/fifteenLove.mp3");}}
            else if(playerTwoCurrentGameScoreInt == 1 && playerOneCurrentGameScoreInt == 2)
                {if(playerOneIsServing)
                {playAudio("src/audio/thirtyFifteen.mp3");}
                else{playAudio("src/audio/fifteenThirty.mp3");}}
            else if(playerTwoCurrentGameScoreInt == 1 && playerOneCurrentGameScoreInt == 3)
                {if(playerOneIsServing)
                {playAudio("src/audio/fortyFifteen.mp3");}
                else{playAudio("src/audio/fifteenForty.mp3");}}
        }
        else if(playerTwoCurrentGameScoreInt == 2)
        {
            if(playerTwoCurrentGameScoreInt == 2 && playerOneCurrentGameScoreInt == 2)
            {playAudio("src/audio/thirtyAll.mp3");}
            else if(playerTwoCurrentGameScoreInt == 2 && playerOneCurrentGameScoreInt == 0)
                {if(playerOneIsServing)
                {playAudio("src/audio/loveThirty.mp3");}
                else{playAudio("src/audio/thirtyLove.mp3");}}
            else if(playerTwoCurrentGameScoreInt == 2 && playerOneCurrentGameScoreInt == 1)
                {if(playerOneIsServing)
                {playAudio("src/audio/fifteenThirty.mp3");}
                else{playAudio("src/audio/thirtyFifteen.mp3");}}
            else if(playerTwoCurrentGameScoreInt == 2 && playerOneCurrentGameScoreInt == 3)
                {if(playerOneIsServing)
                {playAudio("src/audio/fortyThirty.mp3");}
                else{playAudio("src/audio/thirtyForty.mp3");}}
        }
        else if(playerTwoCurrentGameScoreInt == 3)
        {
        if(playerTwoCurrentGameScoreInt == 3 && playerOneCurrentGameScoreInt == 3)
        {playAudio("src/audio/fortyAll.mp3");}
        else if(playerTwoCurrentGameScoreInt == 3 && playerOneCurrentGameScoreInt == 0)
            {if(playerOneIsServing)
            {playAudio("src/audio/loveForty.mp3");}
            else{playAudio("src/audio/fortyLove.mp3");}}
        else if(playerTwoCurrentGameScoreInt == 3 && playerOneCurrentGameScoreInt == 1)
            {if(playerOneIsServing)
            {playAudio("src/audio/fifteenForty.mp3");}
            else{playAudio("src/audio/fortyFifteen.mp3");}}
        else if(playerTwoCurrentGameScoreInt == 3 && playerOneCurrentGameScoreInt == 2)
            {if(playerOneIsServing)
            {playAudio("src/audio/thirtyForty.mp3");}
            else{playAudio("src/audio/fortyThirty.mp3");}}
        }

        //Logic for winning game tiebreak
        if(playerTwoCurrentGameScoreInt > 3 && playerOneCurrentGameScoreInt >= 3 &&
                playerTwoCurrentGameScoreInt > playerOneCurrentGameScoreInt + 1)
        {
            playerTwoCurrentGameScoreInt += 100;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }

        // If player has been given a 100 point boost from the setCurrentScore() method they win the game
        if (playerTwoCurrentGameScoreInt > 100)
        {

                alertPlayerTwoGameWin();


            changeServer();

            if (!setOneComplete) {
                playerTwoSetOneScore++;
                labelPlayerTwoSetScoreSetOne.setText(" " + playerTwoSetOneScore);

                if((playerTwoSetOneScore >= 6 && playerOneSetOneScore <= 4) ||
                        ((playerTwoSetOneScore >= 5 && playerOneSetOneScore >= 5) &&
                                (playerTwoSetOneScore > playerOneSetOneScore + 1)))
                    {setOneComplete = true;
                    playerTwoSetsWon++;
                    numberOfSetsPlayed++;

                    if (playerTwoSetsWon > bestOf / 2)
                    {alertPlayerTwoMatchWin();
                        playerTwoWins = true;}
                    else{alertPlayerTwoSetWin();}
                    }

            }else if (!setTwoComplete) {
                playerTwoSetTwoScore++;
                labelPlayerTwoSetScoreSetTwo.setText(" " + playerTwoSetTwoScore);

                if((playerTwoSetTwoScore >= 6 && playerOneSetTwoScore <= 4) ||
                        ((playerTwoSetTwoScore >= 5 && playerOneSetTwoScore >= 5) &&
                                (playerTwoSetTwoScore > playerOneSetTwoScore + 1)))
                    {setTwoComplete = true;
                    playerTwoSetsWon++;
                    numberOfSetsPlayed++;

                    if (playerTwoSetsWon > bestOf / 2)
                    {alertPlayerTwoMatchWin();
                        playerTwoWins = true;}
                    else{alertPlayerTwoSetWin();}

                    }

            }else if (!setThreeComplete) {
                playerTwoSetThreeScore++;
                labelPlayerTwoSetScoreSetThree.setText(" " + playerTwoSetThreeScore);

                if((playerTwoSetThreeScore >= 6 && playerOneSetThreeScore <= 4) ||
                        ((playerTwoSetThreeScore >= 5 && playerOneSetThreeScore >= 5) &&
                                (playerTwoSetThreeScore > playerOneSetThreeScore + 1)))
                    {setThreeComplete = true;
                    playerTwoSetsWon++;
                    numberOfSetsPlayed++;

                    if (playerTwoSetsWon > bestOf / 2)
                    {alertPlayerTwoMatchWin();
                        playerTwoWins = true;}
                    else{alertPlayerTwoSetWin();}
                }

            }else if (!setFourComplete) {
                playerTwoSetFourScore++;
                labelPlayerTwoSetScoreSetFour.setText(" " + playerTwoSetFourScore);

                if((playerTwoSetFourScore >= 6 && playerOneSetFourScore <= 4) ||
                        ((playerTwoSetFourScore >= 5 && playerOneSetFourScore >= 5) &&
                                (playerTwoSetFourScore > playerOneSetFourScore + 1)))
                    {setFourComplete = true;
                    playerTwoSetsWon++;
                    numberOfSetsPlayed++;

                    if (playerTwoSetsWon > bestOf / 2) {
                        alertPlayerTwoMatchWin();
                        playerTwoWins = true;
                    } else {
                        alertPlayerTwoSetWin();
                    }
                }

            }else if (!setFiveComplete) {
                playerTwoSetFiveScore++;
                labelPlayerTwoSetScoreSetFive.setText(" " + playerTwoSetFiveScore);

                if((playerTwoSetFiveScore >= 6 && playerOneSetFiveScore <= 4) ||
                        ((playerTwoSetFiveScore >= 5 && playerOneSetFiveScore >= 5) &&
                                (playerTwoSetFiveScore > playerOneSetFiveScore + 1)))
                    {setFiveComplete = true;
                    playerTwoSetsWon++;
                    numberOfSetsPlayed++;

                    if (playerTwoSetsWon > bestOf / 2) {
                        alertPlayerTwoMatchWin();
                        playerTwoWins = true;
                    } else {
                        alertPlayerTwoSetWin();
                    }
                }
            }

        }
    }

    public void alertPlayerOneGameWin()
    {
        if(playerOneWins)
        {playAudio("src/audio/gameSetMatchPlayerOne.mp3");}
        else
        {playAudio("src/audio/gamePlayerOne.mp3");}

        //Reset game Scores
        playerOneCurrentGameScoreInt = 0;
        playerTwoCurrentGameScoreInt = 0;
        labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
        labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");

    }

    public void alertPlayerTwoGameWin()
    {
        if(playerTwoWins)
        {   //Ignore Audio Cue
            //Reset game Scores
            playerOneCurrentGameScoreInt = 0;
            playerTwoCurrentGameScoreInt = 0;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }
        else
        {
            playAudio("src/audio/gamePlayerTwo.mp3");

            //Reset game Scores
            playerOneCurrentGameScoreInt = 0;
            playerTwoCurrentGameScoreInt = 0;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }
    }

    public void alertPlayerOneSetWin()
    {
        if(playerOneWins)
        {playAudio("src/audio/gameSetMatchPlayerOne.mp3");}
        else
        {playAudio("src/audio/setPlayerOne.mp3");}

        //Reset game Scores
        playerOneCurrentGameScoreInt = 0;
        playerTwoCurrentGameScoreInt = 0;
        labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
        labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");

    }

    public void alertPlayerTwoSetWin()
    {
        if(playerTwoWins)
        {   //Ignore Audio Cue
            //Reset game Scores
            playerOneCurrentGameScoreInt = 0;
            playerTwoCurrentGameScoreInt = 0;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }
        else
        {
            playAudio("src/audio/setPlayerTwo.mp3");

            //Reset game Scores
            playerOneCurrentGameScoreInt = 0;
            playerTwoCurrentGameScoreInt = 0;
            labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
            labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
        }
    }

    public void alertPlayerTwoMatchWin()
    {
        playAudio("src/audio/gameSetMatchPlayerTwo.mp3");

        //Reset game Scores
        playerOneCurrentGameScoreInt = 0;
        playerTwoCurrentGameScoreInt = 0;
        labelPlayerOneCurrentGameScore.setText("\uD83D\uDDA4");
        labelPlayerTwoCurrentGameScore.setText("\uD83D\uDDA4");
    }

    public void changeServer()
    {
        if (playerOneIsServing) {
            labelPlayerOneServeIndicator.setGraphic(null);
            labelPlayerTwoServeIndicator.setGraphic(ballPane);

            playerOneIsServing = false;
            playerTwoIsServing = true;
        } else {
            labelPlayerOneServeIndicator.setGraphic(ballPane);
            labelPlayerTwoServeIndicator.setGraphic(null);

            playerOneIsServing = true;
            playerTwoIsServing = false;
        }

    }

    public void hideSetsFourAndFive()
    {
        labelPlayerOneSetScoreSetFour.setText("");
        labelPlayerOneSetScoreSetFive.setText("");
        labelPlayerOneSetScoreSetFourTiebreak.setText("");
        labelPlayerOneSetScoreSetFiveTiebreak.setText("");

        labelPlayerTwoSetScoreSetFour.setText("");
        labelPlayerTwoSetScoreSetFive.setText("");
        labelPlayerTwoSetScoreSetFourTiebreak.setText("");
        labelPlayerTwoSetScoreSetFiveTiebreak.setText("");

        labelSetFourNumberText.setText("");
        labelSetFiveNumberText.setText("");
    }


    public void hideSetsTwoThroughFive()
    {
        labelPlayerOneSetScoreSetTwo.setText("");
        labelPlayerOneSetScoreSetThree.setText("");
        labelPlayerOneSetScoreSetFour.setText("");
        labelPlayerOneSetScoreSetFive.setText("");
        labelPlayerOneSetScoreSetTwoTiebreak.setText("");
        labelPlayerOneSetScoreSetThreeTiebreak.setText("");
        labelPlayerOneSetScoreSetFourTiebreak.setText("");
        labelPlayerOneSetScoreSetFiveTiebreak.setText("");

        labelPlayerTwoSetScoreSetTwo.setText("");
        labelPlayerTwoSetScoreSetThree.setText("");
        labelPlayerTwoSetScoreSetFour.setText("");
        labelPlayerTwoSetScoreSetFive.setText("");
        labelPlayerTwoSetScoreSetTwoTiebreak.setText("");
        labelPlayerTwoSetScoreSetThreeTiebreak.setText("");
        labelPlayerTwoSetScoreSetFourTiebreak.setText("");
        labelPlayerTwoSetScoreSetFiveTiebreak.setText("");

        labelSetTwoNumberText.setText("");
        labelSetThreeNumberText.setText("");
        labelSetFourNumberText.setText("");
        labelSetFiveNumberText.setText("");
    }

    public static void playAudio(String audioFilePath) {

        // Load the audio file
        Media media = new Media(new File(audioFilePath).toURI().toString());

        // Create a MediaPlayer
        MediaPlayer mediaPlayer = new MediaPlayer(media);

        // Play the audio
        mediaPlayer.play();







        /*
        "src/audio/changeOverDrinkWater.mp3"
        "src/audio/one.mp3"
        "src/audio/two.mp3"
        "src/audio/three.mp3"
        "src/audio/four.mp3"
        "src/audio/five.mp3"
        "src/audio/six.mp3"
        "src/audio/seven.mp3"
        "src/audio/eight.mp3"
        "src/audio/nine.mp3"
        "src/audio/ten.mp3"
        "src/audio/eleven.mp3"
        "src/audio/twelve.mp3"
        "src/audio/thirteen.mp3"
        "src/audio/fourteen.mp3"
        "src/audio/fifteen.mp3"
        "src/audio/sixteen.mp3"
        */

    }

    public void resume() {
        // Stop the timeline when the application is closed
        timeline.play();
    }

    public void pause() {
        // Pause the timeline when the application is closed
        timeline.pause();
    }

    @Override
    public void stop() {
        // Stop the timeline when the application is closed
        timeline.stop();
    }

    //</editor-fold> END OF METHODS

    public static void main(String[] args) {
        launch(args);
    }
}
