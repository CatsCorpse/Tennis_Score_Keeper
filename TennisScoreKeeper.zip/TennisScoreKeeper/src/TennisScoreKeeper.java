import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.*;


import javax.swing.*;

public class TennisScoreKeeper extends Application {

    private int hours = 0;
    private int minutes = 0;
    private int seconds = 0;
    private Timeline timeline;

    //Player One score variables
    int playerOneSetOneScore, playerOneSetOneTiebreakScore, playerOneSetTwoScore, playerOneSetTwoTiebreakScore,
            playerOneSetThreeScore, playerOneSetThreeTiebreakScore, playerOneSetFourScore, playerOneSetFourTiebreakScore,
            playerOneSetFiveScore, playerOneSetFiveTiebreakScore;

    //Player Two score variables
    int playerTwoSetOneScore, playerTwoSetOneTiebreakScore, playerTwoSetTwoScore, playerTwoSetTwoTiebreakScore,
            playerTwoSetThreeScore, playerTwoSetThreeTiebreakScore, playerTwoSetFourScore, playerTwoSetFourTiebreakScore,
            playerTwoSetFiveScore, playerTwoSetFiveTiebreakScore;

    String playerOneNameString, playerTwoNameString,
            playerOneCountryString, playerTwoCountryString,
            playerOneServing = "Serving", playerTwoServing;

    int playerOneCurrentGameScoreInt, playerTwoCurrentGameScoreInt;

    boolean playerOneIsServing = true, playerTwoIsServing = false, tiebreakIsHappening = false;

    @Override
    public void start(Stage primaryStage) {

        // SET TITLE
        primaryStage.setTitle("DTS Score Keeper");

        //-------------------------------------------------------------------------------------------------------------
        //=============================================================================================================
        // GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS    ###########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS )">
        Label labelTimer = new Label("00:00:00");
        labelTimer.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // Create a timeline to update the timer label every second
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Increment seconds and format the time
                seconds++;
                if (seconds == 60) {
                    seconds = 0;
                    minutes++;
                }
                if (minutes == 60) {
                    minutes = 0;
                    hours++;
                }
                String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                labelTimer.setText(time);
            }
        }));
        timeline.setCycleCount(Animation.INDEFINITE);

        // Start the timeline
        timeline.play();

        // HBOX FOR TIMER
        HBox hBoxLabelTimer = new HBox();
        hBoxLabelTimer.getChildren().addAll(labelTimer);
        hBoxLabelTimer.setPrefSize(50, 25);

        // MATCH TIME LABEL AND BOX
        Label labelMatchTime = new Label("MATCH TIME");

        HBox hBoxLabelMatchTime = new HBox();
        hBoxLabelMatchTime.getChildren().addAll(labelMatchTime);
        hBoxLabelMatchTime.setPrefSize(50, 25);

        // VBox FOR MATCH TIME LABEL AND TIMER
        VBox vBoxTimer = new VBox();
        vBoxTimer.setPrefSize(100, 50);
        vBoxTimer.getChildren().addAll(hBoxLabelMatchTime, hBoxLabelTimer);

        //---------------------------------------------------------------

        // TextFields for Player Names and Countries
        TextField textFieldAddPlayerOneName = new TextField();
        textFieldAddPlayerOneName.setPromptText("Name Player One");
        TextField textFieldAddPlayerTwoName = new TextField();
        textFieldAddPlayerTwoName.setPromptText("Name Player Two");
        TextField textFieldPlayerOneSetCountry = new TextField();
        textFieldPlayerOneSetCountry.setPromptText("Country");
        TextField textFieldPlayerTwoSetCountry = new TextField();
        textFieldPlayerTwoSetCountry.setPromptText("Country");

        //VBox for Setting Names
        VBox vBoxSetNames = new VBox();
        vBoxSetNames.getChildren().addAll(textFieldAddPlayerOneName, textFieldAddPlayerTwoName);
        vBoxSetNames.setPrefSize(120, 50);

        //VBox for Setting Country
        VBox vBoxSetCountry = new VBox();
        vBoxSetCountry.getChildren().addAll(textFieldPlayerOneSetCountry, textFieldPlayerTwoSetCountry);
        vBoxSetCountry.setPrefSize(70, 50);

        //---------------------------------------------------------------

        //Radio Button Section

        // Game Type Radio Button Selection
        Label labelSetGameType = new Label("Game Type:");
        RadioButton radioButtonSetThreeSets = new RadioButton("3 Sets");
        RadioButton radioButtonSetFiveSets = new RadioButton("5 Sets");
        RadioButton radioButtonSetPlayTiebreak = new RadioButton("Play Tiebreak");

        // Tiebreak Type Radio Button Selection
        Label labelSetTiebreakType = new Label("Tiebreak Type:");
        RadioButton radioButtonTenPointTiebreak = new RadioButton("10-point");
        RadioButton radioButtonSevenPointTiebreak = new RadioButton("7-point");

        // Game Type ToggleGroup
        ToggleGroup toggleGroupGameType = new ToggleGroup();
        radioButtonSetThreeSets.setToggleGroup(toggleGroupGameType);
        radioButtonSetFiveSets.setToggleGroup(toggleGroupGameType);
        radioButtonSetPlayTiebreak.setToggleGroup(toggleGroupGameType);

        // Tiebreak Type ToggleGroup
        ToggleGroup toggleGroupTiebreakType = new ToggleGroup();
        radioButtonTenPointTiebreak.setToggleGroup(toggleGroupTiebreakType);
        radioButtonSevenPointTiebreak.setToggleGroup(toggleGroupTiebreakType);

        // Set default selections
        radioButtonSetThreeSets.setSelected(true);
        radioButtonTenPointTiebreak.setSelected(true);

        // VBox for Game Type Radio Buttons and Label
        VBox vBoxGameTypeSelectionBox = new VBox();
        vBoxGameTypeSelectionBox.setPrefSize(70, 50);
        vBoxGameTypeSelectionBox.setStyle("-fx-border-style: hidden;");
        vBoxGameTypeSelectionBox.getChildren().addAll(labelSetGameType,
                radioButtonSetThreeSets, radioButtonSetFiveSets, radioButtonSetPlayTiebreak);

        // VBox for Tiebreak Type Radio Buttons and Label
        VBox vBoxTiebreakSelectionBox = new VBox();
        vBoxTiebreakSelectionBox.setPrefSize(100, 50);
        vBoxTiebreakSelectionBox.setStyle("-fx-border-style: hidden;");
        vBoxTiebreakSelectionBox.getChildren().addAll(labelSetTiebreakType,
                radioButtonTenPointTiebreak, radioButtonSevenPointTiebreak);

        //---------------------------------------------------------------

        // Buttons
        Button buttonChangeServer = new Button("Change Server");
        buttonChangeServer.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        Button buttonStartMatch = new Button("Start Match");
        buttonStartMatch.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels

        // VBox Button Stacks
        VBox vBoxButtonStackOne = new VBox();
        vBoxButtonStackOne.setStyle("-fx-border-style: hidden;");
        vBoxButtonStackOne.setPrefSize(100, 50);
        vBoxButtonStackOne.getChildren().addAll(buttonChangeServer, buttonStartMatch);

        //HBox for Control space
        HBox hBoxControlSpaceOne = new HBox(10);
        hBoxControlSpaceOne.getChildren().addAll(vBoxGameTypeSelectionBox, vBoxTiebreakSelectionBox,
                vBoxButtonStackOne);
        hBoxControlSpaceOne.setPrefSize(310, 50);

        //---------------------------------------------------------------

        //HBox for bottom row GUI
        HBox hBoxBottomRowGUI = new HBox();
        hBoxBottomRowGUI.getChildren().addAll(vBoxSetNames, vBoxSetCountry, hBoxControlSpaceOne, vBoxTimer);
        hBoxBottomRowGUI.setPrefSize(600, 50);

        //</editor-fold> END OF GUI FOR TIMER, PLAYER SETTINGS AND BUTTONS
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name
        Label labelPlayerOneName = new Label(playerOneNameString);
        labelPlayerOneName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneName = new HBox();
        hBoxPlayerOneName.getChildren().addAll(labelPlayerOneName);
        labelPlayerOneName.setPrefSize(125, 75); // width, height

        //Plus point button
        Button buttonPlusPointPlayerOne = new Button("+");
        buttonPlusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        Button buttonMinusPointPlayerOne = new Button("-");
        buttonMinusPointPlayerOne.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerOne.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerOne = new HBox();
        hBoxPlusMinusPointPlayerOne.getChildren().addAll(buttonPlusPointPlayerOne, buttonMinusPointPlayerOne);
        hBoxPlusMinusPointPlayerOne.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerOneNameAndPointControl = new VBox();
        vBoxPlayerOneNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerOneNameAndPointControl.getChildren().addAll(hBoxPlayerOneName, hBoxPlusMinusPointPlayerOne);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        Label labelPlayerOneCountry = new Label();
        labelPlayerOneCountry.setText(playerOneCountryString); // Temporary string until controls are set
        labelPlayerOneCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerOneCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Name
        HBox hBoxPlayerOneCountry = new HBox();
        hBoxPlayerOneCountry.getChildren().addAll(labelPlayerOneCountry);
        hBoxPlayerOneCountry.setPrefSize(50, 75);// width, height

        //Label for Players Serve Turn
        Label labelPlayerOneServeIndicator = new Label(playerOneServing); // Temporary String until logic set
        labelPlayerOneServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerOneServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerOneServeIndicator = new HBox();
        hBoxPlayerOneServeIndicator.getChildren().addAll(labelPlayerOneServeIndicator);
        hBoxPlayerOneServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerOneCountryAndServeIndicator = new VBox();
        vBoxPlayerOneCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerOneCountryAndServeIndicator.getChildren().addAll(hBoxPlayerOneCountry, hBoxPlayerOneServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        Label labelPlayerOneCurrentGameScore = new Label();
        labelPlayerOneCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerOneCurrentGameScore = new VBox();
        vBoxPlayerOneCurrentGameScore.getChildren().addAll(labelPlayerOneCurrentGameScore);
        vBoxPlayerOneCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneAllVBoxes = new HBox();
        hBoxPlayerOneAllVBoxes.getChildren().addAll(vBoxPlayerOneNameAndPointControl,
                                                    vBoxPlayerOneCountryAndServeIndicator,
                                                    vBoxPlayerOneCurrentGameScore);
        hBoxPlayerOneAllVBoxes.setPrefSize(300, 125);// width, height


        //</editor-fold> END OF GUI FOR PLAYER ONE NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO NAME, POINT CONTROL...)">

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
        //Label for Players Name
        Label labelPlayerTwoName = new Label(playerTwoNameString);
        labelPlayerTwoName.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoName.setPrefSize(125, 75); // width, height

        //HBox to hold Players Name
        HBox hBoxPlayerTwoName = new HBox();
        hBoxPlayerTwoName.getChildren().addAll(labelPlayerTwoName);
        hBoxPlayerTwoName.setPrefSize(125, 75); // width, height

        //Plus point button
        Button buttonPlusPointPlayerTwo = new Button("+");
        buttonPlusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonPlusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //Minus point button
        Button buttonMinusPointPlayerTwo = new Button("-");
        buttonMinusPointPlayerTwo.setPrefSize(62.5, 50); // width, height
        buttonMinusPointPlayerTwo.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        //HBox to hold Plus and Minus point buttons
        HBox hBoxPlusMinusPointPlayerTwo = new HBox();
        hBoxPlusMinusPointPlayerTwo.getChildren().addAll(buttonPlusPointPlayerTwo, buttonMinusPointPlayerTwo);
        hBoxPlusMinusPointPlayerTwo.setPrefSize(125, 50); // width, height

        //VBox to hold Players name and associated Plus and Minus point buttons
        VBox vBoxPlayerTwoNameAndPointControl = new VBox();
        vBoxPlayerTwoNameAndPointControl.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoNameAndPointControl.getChildren().addAll(hBoxPlayerTwoName, hBoxPlusMinusPointPlayerTwo);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Country of Origin
        Label labelPlayerTwoCountry = new Label();
        labelPlayerTwoCountry.setText(playerTwoCountryString); // Temporary string until controls are set
        labelPlayerTwoCountry.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //HBox to hold Players Country of Origin
        HBox hBoxPlayerTwoCountry = new HBox();
        hBoxPlayerTwoCountry.getChildren().addAll(labelPlayerTwoCountry);
        hBoxPlayerTwoCountry.setPrefSize(50, 75);// width, height

        //Label for Players Serve Turn
        Label labelPlayerTwoServeIndicator = new Label(""); // Temporary String until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-background-color: #ffcc00;"); // Temporary until logic set
        labelPlayerTwoServeIndicator.setStyle("-fx-font-size: 10px;"); // Set the text size to 20 pixels
        labelPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //HBox to hold Players Serve Turn
        HBox hBoxPlayerTwoServeIndicator = new HBox();
        hBoxPlayerTwoServeIndicator.getChildren().addAll(labelPlayerTwoServeIndicator);
        hBoxPlayerTwoServeIndicator.setPrefSize(50, 50);// width, height

        //VBox to hold Players Country of Origin and Serve Turn
        VBox vBoxPlayerTwoCountryAndServeIndicator = new VBox();
        vBoxPlayerTwoCountryAndServeIndicator.setPrefSize(125, 125); // width, height
        vBoxPlayerTwoCountryAndServeIndicator.getChildren().addAll(hBoxPlayerTwoCountry, hBoxPlayerTwoServeIndicator);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        //Label for Players Current Game Score
        Label labelPlayerTwoCurrentGameScore = new Label();
        labelPlayerTwoCurrentGameScore.setStyle("-fx-font-size: 80px;"); // Set the text size to 20 pixels
        labelPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //HBox to hold Players Current Game Score
        VBox vBoxPlayerTwoCurrentGameScore = new VBox();
        vBoxPlayerTwoCurrentGameScore.getChildren().addAll(labelPlayerTwoCurrentGameScore);
        vBoxPlayerTwoCurrentGameScore.setPrefSize(125, 125);// width, height

        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoAllVBoxes = new HBox();
        hBoxPlayerTwoAllVBoxes.getChildren().addAll(vBoxPlayerTwoNameAndPointControl,
                vBoxPlayerTwoCountryAndServeIndicator,
                vBoxPlayerTwoCurrentGameScore);
        hBoxPlayerTwoAllVBoxes.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO NAME, POINT CONTROL, SERVE TURN, COUNTRY AND CURRENT GAME SCORE
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER ONE SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER ONE SET SCORES)">

        VBox vBoxPlayerOneSetScoreBlankSpace = new VBox();
        vBoxPlayerOneSetScoreBlankSpace.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        Text labelPlayerOneSetScoreSetOne = new Text();// Temporary String
        labelPlayerOneSetScoreSetOne.setText(" " + playerOneSetOneScore); // Temporary String
        labelPlayerOneSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        Text labelPlayerOneSetScoreSetOneTiebreak = new Text();
        labelPlayerOneSetScoreSetOneTiebreak.setText("" + playerOneSetOneTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetOne = new TextFlow(labelPlayerOneSetScoreSetOne, labelPlayerOneSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerOneSetScoreSetOne = new VBox();
        vBoxPlayerOneSetScoreSetOne.getChildren().addAll(textFlowPlayerOneSetScoreSetOne);
        vBoxPlayerOneSetScoreSetOne.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        Text labelPlayerOneSetScoreSetTwo = new Text();
        labelPlayerOneSetScoreSetTwo.setText(" " + playerOneSetTwoScore); // Temporary String
        labelPlayerOneSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        Text labelPlayerOneSetScoreSetTwoTiebreak = new Text();
        labelPlayerOneSetScoreSetTwoTiebreak.setText("" + playerOneSetTwoTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetTwo = new TextFlow(labelPlayerOneSetScoreSetTwo, labelPlayerOneSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerOneSetScoreSetTwo = new VBox();
        vBoxPlayerOneSetScoreSetTwo.getChildren().addAll(textFlowPlayerOneSetScoreSetTwo);
        vBoxPlayerOneSetScoreSetTwo.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        Text labelPlayerOneSetScoreSetThree = new Text();
        labelPlayerOneSetScoreSetThree.setText(" " + playerOneSetThreeScore); // Temporary String
        labelPlayerOneSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        Text labelPlayerOneSetScoreSetThreeTiebreak = new Text();
        labelPlayerOneSetScoreSetThreeTiebreak.setText("" + playerOneSetThreeTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetThree = new TextFlow(labelPlayerOneSetScoreSetThree, labelPlayerOneSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerOneSetScoreSetThree = new VBox();
        vBoxPlayerOneSetScoreSetThree.getChildren().addAll(textFlowPlayerOneSetScoreSetThree);
        vBoxPlayerOneSetScoreSetThree.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        Text labelPlayerOneSetScoreSetFour = new Text();
        labelPlayerOneSetScoreSetFour.setText(" " + playerOneSetFourScore); // Temporary String
        labelPlayerOneSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        Text labelPlayerOneSetScoreSetFourTiebreak = new Text();
        labelPlayerOneSetScoreSetFourTiebreak.setText("" + playerOneSetFourTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFour = new TextFlow(labelPlayerOneSetScoreSetFour, labelPlayerOneSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerOneSetScoreSetFour = new VBox();
        vBoxPlayerOneSetScoreSetFour.getChildren().addAll(textFlowPlayerOneSetScoreSetFour);
        vBoxPlayerOneSetScoreSetFour.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        Text labelPlayerOneSetScoreSetFive = new Text();
        labelPlayerOneSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerOneSetScoreSetFive.setText(" " + playerOneSetFiveScore); // Temporary String


        // Tiebreak Score Number Set Five
        Text labelPlayerOneSetScoreSetFiveTiebreak = new Text();
        labelPlayerOneSetScoreSetFiveTiebreak.setText("" + playerOneSetFiveTiebreakScore); // Temporary String
        labelPlayerOneSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerOneSetScoreSetFive = new TextFlow(labelPlayerOneSetScoreSetFive, labelPlayerOneSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerOneSetScoreSetFive = new VBox();
        vBoxPlayerOneSetScoreSetFive.getChildren().addAll(textFlowPlayerOneSetScoreSetFive);
        vBoxPlayerOneSetScoreSetFive.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerOneSetScoresFinalBox = new HBox();
        hBoxPlayerOneSetScoresFinalBox.getChildren().addAll(vBoxPlayerOneSetScoreBlankSpace,
                vBoxPlayerOneSetScoreSetOne, vBoxPlayerOneSetScoreSetTwo, vBoxPlayerOneSetScoreSetThree,
                vBoxPlayerOneSetScoreSetFour, vBoxPlayerOneSetScoreSetFive);
        hBoxPlayerOneSetScoresFinalBox.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER ONE SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR PLAYER TWO SET SCORES   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR PLAYER TWO SET SCORES)">
        VBox vBoxPlayerTwoSetScoreBlankSpace = new VBox();
        vBoxPlayerTwoSetScoreBlankSpace.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set One
        Text labelPlayerTwoSetScoreSetOne = new Text();// Temporary String
        labelPlayerTwoSetScoreSetOne.setText(" " + playerTwoSetOneScore); // Temporary String
        labelPlayerTwoSetScoreSetOne.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set One
        Text labelPlayerTwoSetScoreSetOneTiebreak = new Text();
        labelPlayerTwoSetScoreSetOneTiebreak.setText("" + playerTwoSetOneTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetOneTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetOne = new TextFlow(labelPlayerTwoSetScoreSetOne, labelPlayerTwoSetScoreSetOneTiebreak);

        // VBox for Set One
        VBox vBoxPlayerTwoSetScoreSetOne = new VBox();
        vBoxPlayerTwoSetScoreSetOne.getChildren().addAll(textFlowPlayerTwoSetScoreSetOne);
        vBoxPlayerTwoSetScoreSetOne.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Two
        Text labelPlayerTwoSetScoreSetTwo = new Text();
        labelPlayerTwoSetScoreSetTwo.setText(" " + playerTwoSetTwoScore); // Temporary String
        labelPlayerTwoSetScoreSetTwo.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Two
        Text labelPlayerTwoSetScoreSetTwoTiebreak = new Text();
        labelPlayerTwoSetScoreSetTwoTiebreak.setText("" + playerTwoSetTwoTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetTwoTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetTwo = new TextFlow(labelPlayerTwoSetScoreSetTwo, labelPlayerTwoSetScoreSetTwoTiebreak);

        // VBox for Set Two
        VBox vBoxPlayerTwoSetScoreSetTwo = new VBox();
        vBoxPlayerTwoSetScoreSetTwo.getChildren().addAll(textFlowPlayerTwoSetScoreSetTwo);
        vBoxPlayerTwoSetScoreSetTwo.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Three
        Text labelPlayerTwoSetScoreSetThree = new Text();
        labelPlayerTwoSetScoreSetThree.setText(" " + playerTwoSetThreeScore); // Temporary String
        labelPlayerTwoSetScoreSetThree.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Three
        Text labelPlayerTwoSetScoreSetThreeTiebreak = new Text();
        labelPlayerTwoSetScoreSetThreeTiebreak.setText("" + playerTwoSetThreeTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetThreeTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetThree = new TextFlow(labelPlayerTwoSetScoreSetThree, labelPlayerTwoSetScoreSetThreeTiebreak);

        // VBox for Set Three
        VBox vBoxPlayerTwoSetScoreSetThree = new VBox();
        vBoxPlayerTwoSetScoreSetThree.getChildren().addAll(textFlowPlayerTwoSetScoreSetThree);
        vBoxPlayerTwoSetScoreSetThree.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Four
        Text labelPlayerTwoSetScoreSetFour = new Text();
        labelPlayerTwoSetScoreSetFour.setText(" " + playerTwoSetFourScore); // Temporary String
        labelPlayerTwoSetScoreSetFour.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels

        // Tiebreak Score Number Set Four
        Text labelPlayerTwoSetScoreSetFourTiebreak = new Text();
        labelPlayerTwoSetScoreSetFourTiebreak.setText("" + playerTwoSetFourTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetFourTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFour = new TextFlow(labelPlayerTwoSetScoreSetFour, labelPlayerTwoSetScoreSetFourTiebreak);

        // VBox for Set Four
        VBox vBoxPlayerTwoSetScoreSetFour = new VBox();
        vBoxPlayerTwoSetScoreSetFour.getChildren().addAll(textFlowPlayerTwoSetScoreSetFour);
        vBoxPlayerTwoSetScoreSetFour.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Main Score Number Set Five
        Text labelPlayerTwoSetScoreSetFive = new Text();
        labelPlayerTwoSetScoreSetFive.setStyle("-fx-font-size: 40px;"); // Set the text size to 20 pixels
        labelPlayerTwoSetScoreSetFive.setText(" " + playerTwoSetFiveScore); // Temporary String

        // Tiebreak Score Number Set Five
        Text labelPlayerTwoSetScoreSetFiveTiebreak = new Text();
        labelPlayerTwoSetScoreSetFiveTiebreak.setText("" + playerTwoSetFiveTiebreakScore); // Temporary String
        labelPlayerTwoSetScoreSetFiveTiebreak.setStyle("-fx-font-size: 12px; -fx-baseline-shift: -6px;"); // Adjust baseline shift as needed

        // TextFlow to hold Scores
        TextFlow textFlowPlayerTwoSetScoreSetFive = new TextFlow(labelPlayerTwoSetScoreSetFive, labelPlayerTwoSetScoreSetFiveTiebreak);

        // VBox for Set Five
        VBox vBoxPlayerTwoSetScoreSetFive = new VBox();
        vBoxPlayerTwoSetScoreSetFive.getChildren().addAll(textFlowPlayerTwoSetScoreSetFive);
        vBoxPlayerTwoSetScoreSetFive.setPrefSize(50, 125);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxPlayerTwoSetScoresFinalBox = new HBox();
        hBoxPlayerTwoSetScoresFinalBox.getChildren().addAll(vBoxPlayerTwoSetScoreBlankSpace,
                vBoxPlayerTwoSetScoreSetOne, vBoxPlayerTwoSetScoreSetTwo, vBoxPlayerTwoSetScoreSetThree,
                vBoxPlayerTwoSetScoreSetFour, vBoxPlayerTwoSetScoreSetFive);
        hBoxPlayerTwoSetScoresFinalBox.setPrefSize(300, 125);// width, height

        //</editor-fold> END OF GUI FOR PLAYER TWO SET SCORES
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR SET SCORES NUMBER INDICATORS   #######################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR SET SCORES NUMBER INDICATORS )">

        Label labelSetsText = new Label();
        labelSetsText.setText("SETS"); // Temporary String
        labelSetsText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        VBox vBoxSetsLabel = new VBox();
        vBoxSetsLabel.setPrefSize(50, 50);// width, height
        vBoxSetsLabel.getChildren().addAll(labelSetsText);
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set One Number
        Label labelSetOneNumberText = new Label();// Temporary String
        labelSetOneNumberText.setText("1"); // Temporary String
        labelSetOneNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set One Number
        VBox vBoxSetOneNumberText = new VBox();
        vBoxSetOneNumberText.getChildren().addAll(labelSetOneNumberText);
        vBoxSetOneNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Two Number
        Label labelSetTwoNumberText = new Label();
        labelSetTwoNumberText.setText("2"); // Temporary String
        labelSetTwoNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Two Number
        VBox vBoxSetTwoNumberText = new VBox();
        vBoxSetTwoNumberText.getChildren().addAll(labelSetTwoNumberText);
        vBoxSetTwoNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Three Number
        Label labelSetThreeNumberText  = new Label();
        labelSetThreeNumberText.setText("3"); // Temporary String
        labelSetThreeNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Three Number
        VBox vBoxSetThreeNumberText  = new VBox();
        vBoxSetThreeNumberText.getChildren().addAll(labelSetThreeNumberText);
        vBoxSetThreeNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Four Number
        Label labelSetFourNumberText = new Label();
        labelSetFourNumberText.setText("4"); // Temporary String
        labelSetFourNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels

        // VBox for Set Four Number
        VBox vBoxSetFourNumberText = new VBox();
        vBoxSetFourNumberText.getChildren().addAll(labelSetFourNumberText);
        vBoxSetFourNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        // Set Five Number
        Label labelSetFiveNumberText = new Label();
        labelSetFiveNumberText.setStyle("-fx-font-size: 20px;"); // Set the text size to 20 pixels
        labelSetFiveNumberText.setText("5"); // Temporary String

        // VBox for Set Five Number
        VBox vBoxSetFiveNumberText = new VBox();
        vBoxSetFiveNumberText.getChildren().addAll(labelSetFiveNumberText);
        vBoxSetFiveNumberText.setPrefSize(50, 50);// width, height
        //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[

        HBox hBoxSetNumberTextFinalBox = new HBox();
        hBoxSetNumberTextFinalBox.getChildren().addAll(vBoxSetsLabel,
                vBoxSetOneNumberText, vBoxSetTwoNumberText, vBoxSetThreeNumberText,
                vBoxSetFourNumberText, vBoxSetFiveNumberText);
        hBoxSetNumberTextFinalBox.setPrefSize(300, 50);// width, height











        //</editor-fold> END OF GUI FOR SET SCORES NUMBER INDICATORS
        //-------------------------------------------------------------------------------------------------------------
        // GUI FOR FINAL SCOREBOARD LAYOUT   ##########################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (GUI FOR FINAL SCOREBOARD LAYOUT)">
        VBox vBoxPlayers = new VBox();
        vBoxPlayers.setPrefSize(300, 250); // width, height
        vBoxPlayers.getChildren().addAll(hBoxPlayerOneAllVBoxes, hBoxPlayerTwoAllVBoxes);

        VBox vBoxScores = new VBox();
        vBoxScores.setPrefSize(300, 250); // width, height
        vBoxScores.getChildren().addAll(hBoxPlayerOneSetScoresFinalBox, hBoxSetNumberTextFinalBox, hBoxPlayerTwoSetScoresFinalBox);

        HBox hBoxTopHalfGUI = new HBox();
        hBoxTopHalfGUI.getChildren().addAll(vBoxPlayers, vBoxScores);

        VBox vBoxFullGUI = new VBox();
        vBoxFullGUI.getChildren().addAll(hBoxTopHalfGUI, hBoxBottomRowGUI);

        StackPane layout = new StackPane();
        layout.getChildren().addAll(vBoxFullGUI);

        Scene scene = new Scene(layout, 600, 325);

        // Load the CSS file
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

        //</editor-fold> END OF GUI FOR FINAL SCOREBOARD LAYOUT
        //-------------------------------------------------------------------------------------------------------------
        // BUTTON HANDLERS   #########################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">

        buttonStartMatch.setOnAction(event -> {
            System.out.println("Start Match Settings Button Clicked!");

            String inputNameOne = textFieldAddPlayerOneName.getText();
            String inputNameTwo = textFieldAddPlayerTwoName.getText();

            String inputCountryOne = textFieldPlayerOneSetCountry.getText();
            String inputCountryTwo = textFieldPlayerTwoSetCountry.getText();

            if (!inputNameOne.isEmpty() && !inputNameTwo.isEmpty() &&
                    !inputCountryOne.isEmpty() && !inputCountryTwo.isEmpty()) {

            // Disable Game Type Radio Buttons
            radioButtonSetThreeSets.setDisable(true);
            radioButtonSetFiveSets.setDisable(true);
            radioButtonSetPlayTiebreak.setDisable(true);

            // Disable Tiebreak Type Radio Buttons
            radioButtonTenPointTiebreak.setDisable(true);
            radioButtonSevenPointTiebreak.setDisable(true);

            // Disable Name TextField
            textFieldAddPlayerOneName.setDisable(true);
            textFieldAddPlayerTwoName.setDisable(true);

            // Disable Country TextField
            textFieldPlayerOneSetCountry.setDisable(true);
            textFieldPlayerTwoSetCountry.setDisable(true);

            // Set Names
            playerOneNameString = textFieldAddPlayerOneName.getText();
            playerTwoNameString = textFieldAddPlayerTwoName.getText();
            labelPlayerOneName.setText(playerOneNameString);
            labelPlayerTwoName.setText(playerTwoNameString);

            // Set Country
            playerOneCountryString = textFieldPlayerOneSetCountry.getText();
            playerTwoCountryString = textFieldPlayerTwoSetCountry.getText();
            labelPlayerOneCountry.setText(playerOneCountryString);
            labelPlayerTwoCountry.setText(playerTwoCountryString);

            startMatch(radioButtonSetThreeSets, radioButtonSetFiveSets, radioButtonTenPointTiebreak,
                    labelPlayerOneCurrentGameScore, labelPlayerTwoCurrentGameScore, labelPlayerOneSetScoreSetFour,
                    labelPlayerOneSetScoreSetFourTiebreak, labelPlayerOneSetScoreSetFive,
                    labelPlayerOneSetScoreSetFiveTiebreak, labelPlayerTwoSetScoreSetFour,
                    labelPlayerTwoSetScoreSetFourTiebreak,  labelPlayerTwoSetScoreSetFive,
                    labelPlayerTwoSetScoreSetFiveTiebreak, labelSetFourNumberText,
                    labelSetFiveNumberText);


            } else {
                // Show an alert
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Empty Text Field");
                alert.setHeaderText(null);
                alert.setContentText("Make sure Player Name and Country have been entered.");
                alert.showAndWait();
            }


        });



        buttonChangeServer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Change Server Button Clicked!");

                if (playerOneIsServing) {
                    playerOneServing = "";
                    playerTwoServing = "Serving";

                    playerOneIsServing = false;
                    playerTwoIsServing = true;
                } else {
                    playerOneServing = "Serving";
                    playerTwoServing = "";

                    playerOneIsServing = true;
                    playerTwoIsServing = false;
                }

                // Update labels
                labelPlayerOneServeIndicator.setText(playerOneServing);
                labelPlayerTwoServeIndicator.setText(playerTwoServing);
            }
        });

        buttonPlusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Plus Point Player One Button Clicked!");

                // Increment Player Score
                playerOneCurrentGameScoreInt++;

                // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
                // Else use standard tennis scoring
                if(tiebreakIsHappening)
                {
                    labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));
                }else {
                    setCurrentScore(playerOneCurrentGameScoreInt, labelPlayerOneCurrentGameScore);
                }
            }
        });

        buttonMinusPointPlayerOne.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Minus Point Player One Button Clicked!");

                // Decrement Player Score
                playerOneCurrentGameScoreInt--;

                // Make sure Players score is never less than 0
                if(playerOneCurrentGameScoreInt < 0)
                {playerOneCurrentGameScoreInt = 0;}

                // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
                // Else use standard tennis scoring
                if(tiebreakIsHappening)
                {
                    labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));
                }else {
                    setCurrentScore(playerOneCurrentGameScoreInt, labelPlayerOneCurrentGameScore);
                }
            }
        });

        buttonPlusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Plus Point Player Two Button Clicked!");

                // Increment Player Score
                playerTwoCurrentGameScoreInt++;

                // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
                // Else use standard tennis scoring
                if(tiebreakIsHappening)
                {
                    labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));
                }else {
                    setCurrentScore(playerTwoCurrentGameScoreInt, labelPlayerTwoCurrentGameScore);
                }            }
        });

        buttonMinusPointPlayerTwo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Minus Point Player Two Button Clicked!");

                // Decrement Player Score
                playerTwoCurrentGameScoreInt--;

                // Make sure Players score is never less than 0
                if(playerTwoCurrentGameScoreInt < 0)
                {playerTwoCurrentGameScoreInt = 0;}

                // If a tiebreak is happening show a digits 1-9 instead of Love, 15, 30 40 and AD
                // Else use standard tennis scoring
                if(tiebreakIsHappening)
                {
                    labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));
                }else {
                    setCurrentScore(playerTwoCurrentGameScoreInt, labelPlayerTwoCurrentGameScore);
                }
            }
        });

        //</editor-fold> END OF BUTTON HANDLERS
    }
    // METHODS  ######################################################################################################
//<<<<<<<<<editor-fold desc=">>>FOLD OF (BUTTON HANDLERS)">

    public void startMatch(RadioButton radioButtonSetThreeSets, RadioButton radioButtonSetFiveSets,
                           RadioButton radioButtonTenPointTiebreak, Label labelPlayerOneCurrentGameScore,
                           Label labelPlayerTwoCurrentGameScore, Text labelPlayerOneSetScoreSetFour,
                           Text labelPlayerOneSetScoreSetFourTiebreak, Text labelPlayerOneSetScoreSetFive,
                           Text labelPlayerOneSetScoreSetFiveTiebreak, Text labelPlayerTwoSetScoreSetFour,
                           Text labelPlayerTwoSetScoreSetFourTiebreak, Text labelPlayerTwoSetScoreSetFive,
                           Text labelPlayerTwoSetScoreSetFiveTiebreak, Label labelSetFourNumberText,
                           Label labelSetFiveNumberText){

        setCurrentScore(playerOneCurrentGameScoreInt, labelPlayerOneCurrentGameScore);
        setCurrentScore(playerTwoCurrentGameScoreInt, labelPlayerTwoCurrentGameScore);

     // Set Tiebreak and Set Number preferences, transition into tiebreak if that's the game type selected
    int bestOf = 0;
    int tiebreakPointNumber;

    if (radioButtonTenPointTiebreak.isSelected())
    {
        tiebreakPointNumber = 10;
    }else {

        tiebreakPointNumber = 7;
    }

    if (radioButtonSetThreeSets.isSelected())
    {
        bestOf = 3;
    }else if (radioButtonSetFiveSets.isSelected()){

        bestOf = 5; // For example, set it to 0
    }else {
            // Starts a tiebreak
            tiebreakIsHappening = true;
            tiebreak(labelPlayerOneCurrentGameScore, labelPlayerTwoCurrentGameScore);
        }
    //---------------------------------------------------------------------------------------------------
    // Start Best of 3 or 5 match

        if(bestOf == 3)
        {
            labelPlayerOneSetScoreSetFour.setText("");
            labelPlayerOneSetScoreSetFive.setText("");
            labelPlayerOneSetScoreSetFourTiebreak.setText("");
            labelPlayerOneSetScoreSetFiveTiebreak.setText("");

            labelPlayerTwoSetScoreSetFour.setText("");
            labelPlayerTwoSetScoreSetFive.setText("");
            labelPlayerTwoSetScoreSetFourTiebreak.setText("");
            labelPlayerTwoSetScoreSetFiveTiebreak.setText("");

            labelSetFourNumberText.setText("");
            labelSetFiveNumberText.setText("");
        }










    }

    public void tiebreak(Label labelPlayerOneCurrentGameScore, Label labelPlayerTwoCurrentGameScore){

        playerOneCurrentGameScoreInt = 0;
        playerTwoCurrentGameScoreInt = 0;

        labelPlayerOneCurrentGameScore.setText(String.valueOf(playerOneCurrentGameScoreInt));
        labelPlayerTwoCurrentGameScore.setText(String.valueOf(playerTwoCurrentGameScoreInt));

    }

    public void setCurrentScore(int currentScore, Label currentScoreDisplayed){

        String outString;
        if(currentScore == 0)
        {
            outString = "\uD83D\uDDA4";
            currentScoreDisplayed.setText(outString);
        } else if(currentScore == 1)
        {
            outString = "15";
            currentScoreDisplayed.setText(outString);
        } else if(currentScore == 2)
        {
            outString = "30";
            currentScoreDisplayed.setText(outString);
        } else if(currentScore == 3)
        {
            outString = "40";
            currentScoreDisplayed.setText(outString);
        }
    }


    @Override
    public void stop() {
        // Stop the timeline when the application is closed
        timeline.stop();
    }

    //</editor-fold> END OF METHODS

    public static void main(String[] args) {
        launch(args);
    }
}
